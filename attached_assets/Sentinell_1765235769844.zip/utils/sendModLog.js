const { WebhookClient, EmbedBuilder } = require('discord.js');
const LogSystem = require('../database/models/LogSystem'); // Ajuste o caminho se necessário
const moment = require('moment-timezone');

/**
 * Envia um log de moderação para o webhook configurado no servidor.
 * @param {import('discord.js').Guild} guild O servidor onde a ação ocorreu.
 * @param {string} actionTitle O título da ação (ex: "Usuário Banido").
 * @param {import('discord.js').User} targetUser O usuário que sofreu a ação.
 * @param {import('discord.js').User} moderator O moderador que executou o comando.
 * @param {string} reason O motivo da ação.
 */
async function sendModLog(guild, actionTitle, targetUser, moderator, reason) {
    if (!guild) return;

    try {
        const config = await LogSystem.findOne({ guildId: guild.id });
        if (!config || !config.webhookUrl) {
            // Se não há webhook configurado para este servidor, simplesmente ignore.
            return;
        }

        const webhookClient = new WebhookClient({ url: config.webhookUrl });

        // Formata a data e hora para o fuso horário de São Paulo
        const timestamp = moment().tz('America/Sao_Paulo').format('DD/MM/YYYY [às] HH:mm:ss');

        const embed = new EmbedBuilder()
            .setColor(3553599)
            .setThumbnail('https://iili.io/FvlzvY7.png')
            .setFooter({
                text: 'Log automático gerado pelo sistema de moderação do Nexus Bot.',
                iconURL: 'https://iili.io/FvlTnHP.png'
            })
            .setDescription(
                `## Nexus Bot - Log de Moderação <:Icon_Moderation_1156072637311750:1394822636353224917>\n\n` +
                `### <:1000154699:1394821885254041650> **${actionTitle} no servidor ${guild.name}**\n` +
                `> - <:1000154607:1394821908469383290> **Usuário:** ${targetUser} (${targetUser.tag})\n` +
                `> - <:Icon_Moderation_1156072637311750:1394822636353224917> **Moderador:** ${moderator} (${moderator.tag})\n` +
                `> - <:Icon_Roles_1182698345811169341:1394822626022789170> **Motivo:** ${reason || 'Nenhum motivo fornecido.'}\n` +
                `> - <:relogio:1394209332580585483> **Horário:** ${timestamp}`
            );

        await webhookClient.send({
            username: 'Nexus Bot Logs',
            avatarURL: 'https://iili.io/FvlzvY7.png', // URL do avatar do seu bot
            embeds: [embed],
        });

        // Conforme solicitado, os dados não são armazenados após o envio,
        // a função lê a configuração, envia e termina.

    } catch (error) {
        console.error(`[ERRO DE LOGS] Não foi possível enviar o log para o servidor ${guild.name} (${guild.id}).`, error);
        // Opcional: Se o webhook for inválido (erro 404), podemos deletá-lo do DB.
        if (error.code === 10015) { // Código de erro para "Unknown Webhook"
            console.log(`[SISTEMA DE LOGS] Webhook inválido detectado no servidor ${guild.name}. Removendo do banco de dados.`);
            await LogSystem.findOneAndDelete({ guildId: guild.id });
        }
    }
}

module.exports = { sendModLog };
