const Mute = require('../database/models/Mute');

module.exports = async (client) => {
  setInterval(async () => {
    const now = new Date();
    const expiredMutes = await Mute.find({ endAt: { $lte: now } });

    for (const mute of expiredMutes) {
      const guild = client.guilds.cache.get(mute.guildId);
      if (!guild) continue;

      const member = await guild.members.fetch(mute.userId).catch(() => null);
      if (member && member.communicationDisabledUntilTimestamp > Date.now()) {
        await member.timeout(null, 'Mute expirado automaticamente.');
      }

      await Mute.deleteOne({ _id: mute._id });
    }
  }, 60 * 1000); // Checa a cada 1 minuto
};