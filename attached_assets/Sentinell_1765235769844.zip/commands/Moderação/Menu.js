const {
  SlashCommandBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  ContainerBuilder,
  SectionBuilder,
  ThumbnailBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  MessageFlags,
} = require('discord.js');
const Perm = require('../../database/models/perms.js');

const OWNER_ID = "968962809054515272";

module.exports = {
  data: new SlashCommandBuilder()
    .setName('menu')
    .setDescription('Abre o painel de gerenciamento de skin mods Saves.'),

  async execute(interaction) {
    const userId = interaction.user.id;
    const isOwner = userId === OWNER_ID;

    const hasPerm = await Perm.findOne({ userId });

    if (!isOwner && !hasPerm) {
      const noPermContainer = new ContainerBuilder()
        .setAccentColor(0xED4245)
        .addSectionComponents(
          new SectionBuilder()
          .setThumbnailAccessory(new ThumbnailBuilder().setURL("https://i.ibb.co/q5L191F/186-Sem-T-tulo-20250920110331.png"))
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              "## Acesso Negado\n" +
              "Você não tem permissão para usar este comando.\n" +
              "Peça ao dono do Bot para lhe conceder acesso."
            )
          )
        )
        .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small))
        .addTextDisplayComponents(new TextDisplayBuilder().setContent("Sentinel Security • Permissões Insuficientes"));

      return interaction.reply({
        components: [noPermContainer],
        flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2
      });
    }

    const descricaoPainel =
      `## Painel Gerenciamento De Recursos Sentinel\n\n` +
      `Olá, ${interaction.user}!\n` +
      "Este painel oferece uma forma rápida e segura de administrar os recursos de Silksong (Mods, Skins e Saves).\n\n" +
      "### Recursos Disponíveis:\n" +
      "- **Skins** – Personalize a aparência ao seu gosto.\n" +
      "- **Saves** – Gerencie e organize seu progresso.\n" +
      "- **Mods** – Ative, desative ou configure facilmente.\n" +
      "- **Fusion Mods** – Gerencie fusões de mods e skins.";

    const selectMenu = new StringSelectMenuBuilder()
      .setCustomId("selecao_opcoes_principais")
      .setPlaceholder("Selecione um painel para gerenciar...")
      .addOptions(
        new StringSelectMenuOptionBuilder()
          .setLabel("Skins")
          .setDescription("Gerenciar todas as skins personalizadas.")
          .setValue("skins"),
        new StringSelectMenuOptionBuilder()
          .setLabel("Saves")
          .setDescription("Gerenciar todos os arquivos de save.")
          .setValue("saves"),
        new StringSelectMenuOptionBuilder()
          .setLabel("Mods")
          .setDescription("Gerenciar todas as modificações (mods).")
          .setValue("mods"),
        new StringSelectMenuOptionBuilder()
          .setLabel("Fusion Mods")
          .setDescription("Gerenciar fusões de mods e skins.")
          .setValue("fusion")
      );

    const actionRow = new ActionRowBuilder().addComponents(selectMenu);

    const mainContainer = new ContainerBuilder()
      .setAccentColor(0x364FFF)
      .addSectionComponents(
        new SectionBuilder()
        .setThumbnailAccessory(new ThumbnailBuilder().setURL("https://i.ibb.co/KAZadhP.png"))
        .addTextDisplayComponents(new TextDisplayBuilder().setContent(descricaoPainel))
      )
      .addActionRowComponents(actionRow);

    await interaction.reply({
      components: [mainContainer],
      flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2
    });
  },
};