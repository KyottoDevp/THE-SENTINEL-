const {
    SlashCommandBuilder,
    ActionRowBuilder,
    StringSelectMenuBuilder,
    ContainerBuilder,
    SectionBuilder,
    TextDisplayBuilder,
    ThumbnailBuilder,
    SeparatorBuilder,
    MessageFlags
} = require('discord.js');
const UsuariosPermitidos = require('../../database/models/perms.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('painel-gerenciamento-sk')
        .setDescription('Abre o painel administrativo para gerenciar os Ports.'),

    async execute(interacao) {
        await interacao.deferReply({
            flags: MessageFlags.Ephemeral
        });

        const permissaoUsuario = await UsuariosPermitidos.findOne({
            userId: interacao.user.id
        });

        if (!permissaoUsuario) {
            const containerSemPermissao = new ContainerBuilder()
                .setAccentColor(0xff0000)
                .addSectionComponents(
                    new SectionBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(
                            '## ⛔ Acesso Negado\n\n' +
                            '❌ Você não tem permissão para usar este comando.\n\n' +
                            '📌 *Para solicitar acesso, por favor, contate a equipe de administração.*'
                        )
                    )
                );

            return interacao.editReply({
                components: [containerSemPermissao],
                flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2
            });
        }

        const descricao =
            `## Painel Administrativo | Silksong Ports\n\n` +
            `- Bem-vindo, **${interacao.user}**. Esta é a sua interface dedicada ao gerenciamento das versões de Hollow Knight Silksong.\n\n` +
            `- Este painel centraliza a administração das diferentes versões, permitindo um controle preciso sobre as versões (Porting Workshop, Weave Wing e Gle Ports).\n\n` +
            `- Para começar, selecione a categoria que deseja gerenciar no menu abaixo.`;

        const menuSelecao = new StringSelectMenuBuilder()
            .setCustomId('selecao_principal_ports') // ID CORRETO MANTIDO
            .setPlaceholder('Selecione uma categoria para gerenciar...')
            .addOptions([{
                label: 'Porting Workshop',
                description: 'Gerenciar os ports da equipe Porting Workshop.',
                value: 'freddy',
            }, {
                label: 'Weave Wing',
                description: 'Gerenciar os ports da equipe Weave Wing.',
                value: 'chines',
            }, {
                label: 'Gle Ports',
                description: 'Gerenciar os ports da equipe Gle Ports.',
                value: 'gleports',
            }, ]);

        const linhaAcao = new ActionRowBuilder().addComponents(menuSelecao);

        const painelContainer = new ContainerBuilder()
            .setAccentColor(0xFFFFFF)
            .addSectionComponents(
                new SectionBuilder()
                .setThumbnailAccessory(new ThumbnailBuilder().setURL('https://i.ibb.co/TMSdLmnP/Rounded-20250929-203853.png'))
                .addTextDisplayComponents(new TextDisplayBuilder().setContent(descricao))
            )
            .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
            .addActionRowComponents(linhaAcao);


        await interacao.editReply({
            components: [painelContainer],
            flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
        });
    },
};