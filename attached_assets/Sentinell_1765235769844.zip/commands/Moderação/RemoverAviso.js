const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const Warn = require('../../database/models/Warn');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unwarn')
    .setDescription('Remove um ou todos os avisos de um usuário.')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('User who will have the warn removed')
        .setRequired(true)
    )
    .addIntegerOption(option =>
      option.setName('warn')
        .setDescription('The warn number to remove (leave empty to clear all warns)')
        .setRequired(false)
    ),

  async execute(interaction) {
    const user = interaction.options.getUser('user');
    const warnIndex = interaction.options.getInteger('warn');
    const member = interaction.guild.members.cache.get(user.id);

    // =======================
    // PERMISSION CHECKS
    // =======================
    if (!interaction.member.permissions.has(PermissionFlagsBits.ModerateMembers)) {
      return interaction.reply({
        content: '<a:erro:1419734220191830146> You do not have permission to remove warns.',
        ephemeral: true
      });
    }

    if (!member) {
      return interaction.reply({
        content: '<a:erro:1419734220191830146> User not found in the server.',
        ephemeral: true
      });
    }

    // =======================
    // FETCH WARNS
    // =======================
    const warns = await Warn.find({ guildId: interaction.guild.id, userId: member.id }).sort({ timestamp: 1 });

    if (warns.length === 0) {
      return interaction.reply({
        content: '<a:erro:1419734220191830146> This user has no warns.',
        ephemeral: true
      });
    }

    let removedWarn;
    if (warnIndex) {
      // =======================
      // REMOVE SPECIFIC WARN
      // =======================
      if (warnIndex < 1 || warnIndex > warns.length) {
        return interaction.reply({
          content: `<a:erro:1419734220191830146> Invalid warn number. This user has only ${warns.length} warn(s).`,
          ephemeral: true
        });
      }

      removedWarn = warns[warnIndex - 1];
      await Warn.findByIdAndDelete(removedWarn._id);
    } else {
      // =======================
      // REMOVE ALL WARNS
      // =======================
      await Warn.deleteMany({ guildId: interaction.guild.id, userId: member.id });
    }

    const warnCount = await Warn.countDocuments({ guildId: interaction.guild.id, userId: member.id });

    // =======================
    // SUCCESS EMBED
    // =======================
    const unwarnEmbed = new EmbedBuilder()
      .setColor(0x2ecc71)
      .setDescription(
        warnIndex
          ? `## <:Moderation:1394887139925426397> Hornet Unwarn System\n- User: ${member}\n- Removed warn #${warnIndex}\n- Moderator: ${interaction.user}\n- Remaining warns: ${warnCount}`
          : `## <:Moderation:1394887139925426397> Hornet Unwarn System\n- User: ${member}\n- All warns have been removed!\n- Moderator: ${interaction.user}`
      )
      .setThumbnail('https://iili.io/KumNYAb.png')
      .setFooter({
        text: 'Hornet Unwarn System',
        iconURL: 'https://iili.io/Kl1JfOg.png',
        proxy_icon_url: 'https://images-ext-1.discordapp.net/external/DrSuJCamguaiA1VsV4Z-X9JkV4Ce9CPvBB8SYDZHWm4/https/iili.io/Kl1JfOg.png'
      });

    await interaction.reply({ embeds: [unwarnEmbed] });
    member.send({ embeds: [unwarnEmbed] }).catch(() => {}); // fail silently if DM fails
  }
};