const {
  SlashCommandBuilder,
  EmbedBuilder,
  PermissionFlagsBits
} = require('discord.js');
const Ban = require('../../database/models/Ban');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('desbanir')
    .setDescription('Remove o banimento de um usuário do servidor.')
    .addStringOption(option =>
      option.setName('id')
        .setDescription('ID of the user to unban.')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('reason')
        .setDescription('Reason for the unban.')
        .setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

  async execute(interaction) {
    await interaction.deferReply({ ephemeral: false });

    const userId = interaction.options.getString('id');
    const reason = interaction.options.getString('reason');

    // Check executor permissions
    if (!interaction.member.permissions.has(PermissionFlagsBits.BanMembers)) {
      return await interaction.editReply({
        content: '❌ You do not have permission to use this command.',
        ephemeral: true
      });
    }

    // Check bot permissions
    if (!interaction.guild.members.me.permissions.has(PermissionFlagsBits.BanMembers)) {
      const embedPermission = new EmbedBuilder()
        .setColor(3553599)
        .setThumbnail('https://iili.io/KumNYAb.png')
        .setDescription('## Hornet System Unban <:Icon_Moderation:1427138768338681856> - **<:Icon_Developer_Options:1427142110032957501> I cannot unban the user due to insufficient permissions. Please check my role permissions.**')
        .setFooter({
          text: "Hornet Bot System Unban",
          iconURL: "https://iili.io/Kl1JfOg.png"
        });

      return await interaction.editReply({ embeds: [embedPermission] });
    }

    try {
      // Fetch user for DM before unban
      const user = await interaction.client.users.fetch(userId).catch(() => null);

      // Unban user
      await interaction.guild.bans.remove(userId, reason);

      const thumbnail = user?.displayAvatarURL({ dynamic: true }) || 'https://iili.io/KumNYAb.png';

      const embedSuccess = new EmbedBuilder()
        .setColor(3553599)
        .setThumbnail(thumbnail)
        .setDescription(`## <:Moderation:1394887139925426397> Hornet System Unban 
- **User has been successfully unbanned!**
- **Reason:** ${reason}
- **User:** ${user ? user.tag : `ID: ${userId}`}`)
        .setFooter({
          text: "Hornet Bot System Unban",
          iconURL: "https://iili.io/Kl1JfOg.png"
        });

      await interaction.editReply({ embeds: [embedSuccess] });

      // DM user if possible
      if (user) {
        const embedDM = new EmbedBuilder()
          .setColor(3553599)
          .setThumbnail('https://iili.io/KumNYAb.png')
          .setDescription(`## Hornet System Unban <:Icon_Moderation:1427138768338681856>
- ** You have been unbanned!**
- ** Reason:** ${reason}
- ** Moderator:** ${interaction.user.tag}`)
          .setFooter({
            text: "Hornet Bot System Unban",
            iconURL: "https://iili.io/Kl1JfOg.png"
          });

        await user.send({ embeds: [embedDM] }).catch(() => null);
      }

      // Remove ban record from MongoDB
      await Ban.deleteOne({ userId, guildId: interaction.guild.id });

    } catch (error) {
      console.error("Error unbanning:", error);

      const embedError = new EmbedBuilder()
        .setColor(0xff0000)
        .setThumbnail('https://iili.io/KumNYAb.png')
        .setDescription(`❌ An error occurred while trying to unban the user with ID \`${userId}\`. Make sure the ID is correct or the user is currently banned.`)
        .setFooter({
          text: "Hornet Bot System Unban",
          iconURL: "https://iili.io/Kl1JfOg.png"
        });

      return await interaction.editReply({ embeds: [embedError] });
    }
  }
};