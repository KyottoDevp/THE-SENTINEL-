const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('expulsar')
    .setDescription('Expulsa um usuário do servidor.')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('The user who will be kicked')
        .setRequired(true)
    )
    .addStringOption(option =>
      option.setName('reason')
        .setDescription('Reason for the kick')
        .setRequired(false)
    ),

  async execute(interaction) {
    const targetUser = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'Not specified';
    const guild = interaction.guild;
    const executor = interaction.member;
    const botMember = guild.members.me;

    /**
     * Cria o embed seguindo o template Hornet System
     */
    function createHornetEmbed({ userName = '-', reasonText = '-', emoji = '<:Icon_Moderation:1427138768338681856>' }) {
      return new EmbedBuilder()
        .setColor(3447003)
        .setDescription(`${emoji} **Hornet Kicks System**\n- **User:** ${userName}\n- **Executor:** ${executor.user.tag}\n- **Reason:** ${reasonText}`)
        .setThumbnail("https://iili.io/KumNYAb.png")
        .setFooter({
          text: "Hornet Kick System",
          iconURL: "https://iili.io/Kl1JfOg.png"
        })
        .setTimestamp();
    }

    // Checa permissão do executor
    if (!executor.permissions.has(PermissionFlagsBits.KickMembers)) {
      const embed = createHornetEmbed({ emoji: '<a:erro:1419734220191830146>', userName: targetUser.tag, reasonText: 'You do not have permission.' });
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    // Checa permissão do bot
    if (!botMember.permissions.has(PermissionFlagsBits.KickMembers)) {
      const embed = createHornetEmbed({ emoji: '<a:erro:1419734220191830146>', userName: targetUser.tag, reasonText: 'Bot lacks permission.' });
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    // Busca membro no servidor
    const guildMember = await guild.members.fetch(targetUser.id).catch(() => null);
    if (!guildMember) {
      const embed = createHornetEmbed({ emoji: '<a:erro:1419734220191830146>', userName: targetUser.tag, reasonText: 'User not found in the server.' });
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    // Checa hierarquia: bot vs target
    if (guildMember.roles.highest.position >= botMember.roles.highest.position) {
      const embed = createHornetEmbed({ emoji: '<a:erro:1419734220191830146>', userName: targetUser.tag, reasonText: 'Target has higher role than the bot.' });
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    // Checa hierarquia: executor vs target
    if (!executor.permissions.has(PermissionFlagsBits.Administrator) && executor.roles.highest.position <= guildMember.roles.highest.position) {
      const embed = createHornetEmbed({ emoji: '<a:erro:1419734220191830146>', userName: targetUser.tag, reasonText: 'Target has higher or equal role than you.' });
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    // Tenta mandar DM para o usuário
    try {
      const dmEmbed = createHornetEmbed({ emoji: '<:Icon_Moderation:1427138768338681856>', userName: targetUser.tag, reasonText: reason });
      await targetUser.send({ embeds: [dmEmbed] });
    } catch {
      // DM falhou, ignora
    }

    // Executa o kick
    try {
      await guildMember.kick(reason);

      const embed = createHornetEmbed({ emoji: '<:1000242198:1419734199727947857>', userName: targetUser.tag, reasonText: reason });
      return interaction.reply({ embeds: [embed], ephemeral: false });
    } catch {
      const embed = createHornetEmbed({ emoji: '<a:erro:1419734220191830146>', userName: targetUser.tag, reasonText: 'Failed to kick the user.' });
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }
  }
};