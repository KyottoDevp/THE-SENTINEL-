const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName('banir')
    .setDescription('Bane permanentemente um usuário do servidor.')
    .addUserOption(option =>
      option
        .setName("user")
        .setDescription("The user to be banned.")
        .setRequired(true)
    )
    .addStringOption(option =>
      option
        .setName("reason")
        .setDescription("Reason for the ban.")
        .setRequired(true)
    ),

  async execute(interaction) {
    await interaction.deferReply({ ephemeral: false });

    // Check permission
    if (!interaction.member.permissions.has(PermissionFlagsBits.BanMembers)) {
      const embedNoPermission = {
        type: "rich",
        color: 15158332,
        description: "## <:opcoes:1394887082970841179> Hornet System Ban\n- **Permission Denied**\n- You lack the permission: `Ban Members`\n- Your Role: " + interaction.member.roles.highest,
        thumbnail: {
          url: "https://iili.io/KumNYAb.png",
          proxy_url: "https://images-ext-1.discordapp.net/external/M_orwYAPm9llCXmLjW7iWvLXcCF9Wu21xgM-ADb9CHk/https/iili.io/KumNYAb.png",
          width: 200,
          height: 200
        },
        footer: {
          text: "Hornet Ban System",
          icon_url: "https://iili.io/Kl1JfOg.png",
          proxy_icon_url: "https://images-ext-1.discordapp.net/external/DrSuJCamguaiA1VsV4Z-X9JkV4Ce9CPvBB8SYDZHWm4/https/iili.io/Kl1JfOg.png"
        },
        timestamp: new Date().toISOString()
      };

      return await interaction.editReply({ embeds: [embedNoPermission], ephemeral: true });
    }

    const user = interaction.options.getUser("user");
    const reason = interaction.options.getString("reason");
    const member = await interaction.guild.members.fetch(user.id).catch(() => null);
    const executor = await interaction.guild.members.fetch(interaction.user.id);

    // Embed: Role hierarchy error
    const embedHigherRole = {
      type: "rich",
      color: 15158332,
      description: `## <:Icon_Moderation:1427138768338681856> Hornet System Ban\n- **Action Blocked**\n- The user's role is higher than mine or yours!\n- User: ${user?.tag ?? "Unknown"}`,
      thumbnail: {
        url: "https://iili.io/FWpkzps.png",
        proxy_url: "https://images-ext-1.discordapp.net/external/M_orwYAPm9llCXmLjW7iWvLXcCF9Wu21xgM-ADb9CHk/https/iili.io/FWpkzps.png",
        width: 200,
        height: 200
      },
      footer: {
        text: "Hornet Ban System",
        icon_url: "https://iili.io/Kl1JfOg.png"
      }
    };

    if (!member) return await interaction.editReply({ embeds: [embedHigherRole], ephemeral: true });

    if (member.roles.highest.position >= interaction.guild.members.me.roles.highest.position)
      return await interaction.editReply({ embeds: [embedHigherRole], ephemeral: true });

    if (member.roles.highest.position >= executor.roles.highest.position)
      return await interaction.editReply({ embeds: [embedHigherRole], ephemeral: true });

    // Embed DM to banned user
    const embedDM = {
      type: "rich",
      color: 15158332,
      description: `## <:Icon_Moderation:1427138768338681856> Hornet System Ban\n- You have been banned from **${interaction.guild.name}**\n- Motive: **${reason}**`,
      thumbnail: {
        url: user.displayAvatarURL({ dynamic: true, size: 256 }),
        width: 200,
        height: 200
      },
      footer: {
        text: "Hornet Ban System",
        icon_url: "https://iili.io/Kl1JfOg.png"
      }
    };

    // Embed confirmation
    const embedConfirmation = {
      type: "rich",
      color: 5763719,
      description: `## <:Moderation:1394887139925426397> Hornet System Ban\n- Successfully banned!\n- User: **${user.tag}**\n- Motive: **${reason}**`,
      thumbnail: {
        url: user.displayAvatarURL({ dynamic: true, size: 256 }),
        width: 200,
        height: 200
      },
      footer: {
        text: "Hornet Ban System",
        icon_url: "https://iili.io/Kl1JfOg.png"
      }
    };

    try {
      await user.send({ embeds: [embedDM] }).catch(() => null);
      await member.ban({ reason });
      await interaction.editReply({ embeds: [embedConfirmation] });
    } catch (error) {
      console.error("Error banning user:", error);

      const embedError = {
        type: "rich",
        color: 15158332,
        description: "## <:opcoes:1394887082970841179> Hornet System Ban\n- An unexpected error occurred while trying to ban this user.",
        thumbnail: {
          url: "https://iili.io/KumNYAb.png",
          width: 200,
          height: 200
        },
        footer: {
          text: "Hornet Ban System",
          icon_url: "https://iili.io/Kl1JfOg.png"
        },
        timestamp: new Date().toISOString()
      };

      if (interaction.deferred || interaction.replied) {
        await interaction.editReply({ embeds: [embedError], ephemeral: true });
      } else {
        await interaction.reply({ embeds: [embedError], ephemeral: true });
      }
    }
  }
};