
const { SlashCommandBuilder } = require("discord.js");
const Perm = require('../../database/models/perms.js');

const OWNER_ID = "1423744686337822904";

// Função para criar embeds no estilo Hornet, nomes em inglês
const createHornetEmbed = (title, userTarget, actionUser, color) => {
    return {
        color: color,
        description: `## Hornet ${title}\n- **<:Moderation:1394887139925426397> Panel ${title} For User:** <@${userTarget}>\n- **<:Moderation:1394887139925426397> Who ${title} The Panel:** <@${actionUser}>`,
        thumbnail: { url: "https://iili.io/KumNYAb.png" },
        type: "rich",
        flags: 0
    };
};

module.exports = {
    data: new SlashCommandBuilder()
        .setName('permissao')
        .setDescription('Gerencia o acesso de um usuário a comandos restritos.')
        .addUserOption(option =>
            option.setName("user")
            .setDescription("The user you want to manage.")
            .setRequired(true))
        .addStringOption(option =>
            option.setName("action")
            .setDescription("Action to perform.")
            .setRequired(true)
            .addChoices(
                { name: 'Grant', value: 'grant' },
                { name: 'Revoke', value: 'revoke' }
            )),

    async execute(interaction) {
        const targetUser = interaction.options.getUser("user");
        const action = interaction.options.getString("action");

        // Check if the executor is the Owner
        if (interaction.user.id !== OWNER_ID) {
            return interaction.reply({
                embeds: [{
                    color: 0xFF0000,
                    description: `## Hornet Access Denied\n- **User Without Permission:** <@${interaction.user.id}>\n- **<:opcoes:1394887082970841179> Attempted To Access The Panel**`,
                    thumbnail: { url: "https://iili.io/KumNYAb.png" },
                    type: "rich",
                    flags: 0
                }],
                ephemeral: true
            });
        }

        // ==============================
        // Grant permission
        // ==============================
        if (action === 'grant') {
            try {
                const userExists = await Perm.findOne({ userId: targetUser.id });

                if (userExists) {
                    return interaction.reply({
                        embeds: [createHornetEmbed("Granted", targetUser.id, interaction.user.id, 0xFFCC00)],
                        ephemeral: true
                    });
                }

                await new Perm({ userId: targetUser.id }).save();
                console.log(`Permission granted to ${targetUser.tag} (${targetUser.id})`);

                return interaction.reply({
                    embeds: [createHornetEmbed("Granted", targetUser.id, interaction.user.id, 0x00FF00)],
                    ephemeral: true
                });

            } catch (error) {
                console.error("Error granting permission:", error);
                return interaction.reply({
                    content: "An error occurred while saving the permission. Check the console.",
                    ephemeral: true
                });
            }
        }

        // ==============================
        // Revoke permission
        // ==============================
        if (action === 'revoke') {
            try {
                const result = await Perm.deleteOne({ userId: targetUser.id });

                if (result.deletedCount === 0) {
                    return interaction.reply({
                        embeds: [createHornetEmbed("Revoked", targetUser.id, interaction.user.id, 0xFFCC00)],
                        ephemeral: true
                    });
                }

                console.log(`Permission revoked from ${targetUser.tag} (${targetUser.id})`);
                return interaction.reply({
                    embeds: [createHornetEmbed("Revoked", targetUser.id, interaction.user.id, 0xDE2E2E)],
                    ephemeral: true
                });

            } catch (error) {
                console.error("Error revoking permission:", error);
                return interaction.reply({
                    content: "An error occurred while revoking the permission. Check the console.",
                    ephemeral: true
                });
            }
        }
    }
};