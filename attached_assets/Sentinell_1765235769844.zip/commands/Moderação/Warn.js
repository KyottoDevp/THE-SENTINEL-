const { 
    SlashCommandBuilder, 
    PermissionFlagsBits, 
    EmbedBuilder,
    ContainerBuilder,
    SectionBuilder,
    ThumbnailBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    MessageFlags
} = require('discord.js');
const Warn = require('../../database/models/Warn');
const WarnConfig = require('../../database/models/warnConfig');
const config = require('../../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('Aplica um aviso a um usuário e registra a infração.')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('User who will receive the warn')
        .setRequired(true)
    )
    .addStringOption(option =>
      option.setName('reason')
        .setDescription('Reason for the warn')
        .setRequired(true)
    ),

  async execute(interaction) {
    const user = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason');
    const member = interaction.guild.members.cache.get(user.id);
    const botMember = interaction.guild.members.me;
    const executor = interaction.member;

    const warnConfig = await WarnConfig.findOne({ guildId: interaction.guild.id });

    if (!warnConfig || !warnConfig.active) {
        const containerConfigError = new ContainerBuilder()
            .setAccentColor(0xFEE75C)
            .addSectionComponents(
                new SectionBuilder()
                    .setThumbnailAccessory(new ThumbnailBuilder().setURL('https://iili.io/f2ePUAJ.png'))
                    .addTextDisplayComponents(
                        new TextDisplayBuilder()
                            .setContent("## ⚠️ Sentinel System | Warn Configuração\n\nO sistema de avisos está **desativado** ou **não foi configurado** neste servidor. Para utilizar esta funcionalidade, um administrador precisa configurar os cargos e ativar o sistema.\n\n**Ação para Administradores:**\nUtilize o comando de configuração `/warnconfig` para definir os cargos de punição e ativar o módulo.")
                    )
            )
            .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small));

        return interaction.reply({
            components: [containerConfigError],
            flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2
        });
    }

    const isOwner = executor.id === config.ownerId;

    if (!isOwner && !executor.permissions.has(PermissionFlagsBits.ModerateMembers)) {
      return interaction.reply({
        content: '<a:erro:1419734220191830146> You do not have permission to apply a warn.',
        ephemeral: true
      });
    }

    if (!member) {
      return interaction.reply({
        content: '<a:erro:1419734220191830146> User not found in the server.',
        ephemeral: true
      });
    }

    if (member.id === executor.id) {
      return interaction.reply({
        content: '<a:erro:1419734220191830146> You cannot warn yourself.',
        ephemeral: true
      });
    }

    if (!isOwner && executor.roles.highest.position <= member.roles.highest.position) {
      return interaction.reply({
        content: `<a:erro:1419734220191830146> You cannot warn ${member.user.tag}. Their position is higher than yours.`,
        ephemeral: true
      });
    }

    if (member.permissions.has('Administrator')) {
      return interaction.reply({
        content: `<a:erro:1419734220191830146> You cannot warn ${member.user.tag} because they are an administrator.`,
        ephemeral: true
      });
    }

    if (botMember.roles.highest.position <= member.roles.highest.position) {
      return interaction.reply({
        content: `<a:erro:1419734220191830146> I cannot warn ${member.user.tag}. Their position is higher than mine.`,
        ephemeral: true
      });
    }

    const newWarn = new Warn({
      guildId: interaction.guild.id,
      userId: member.id,
      moderatorId: executor.id,
      reason: reason,
      timestamp: new Date()
    });

    try {
      await newWarn.save();
      console.log(`✅ Warn applied to ${member.user.tag} by ${executor.user.tag} | Reason: ${reason}`);
    } catch (error) {
      console.error('❌ Error saving warn:', error);
      return interaction.reply({
        content: '<a:erro:1419734220191830146> An error occurred while saving the warn to the database.',
        ephemeral: true
      });
    }

    const warnCount = await Warn.countDocuments({ guildId: interaction.guild.id, userId: member.id });

    let roleErrorOccurred = false;

    try {
        const configuredRoles = warnConfig.warnRoles || [];
        
        const rolesToRemove = configuredRoles.filter(roleId => member.roles.cache.has(roleId));
        if (rolesToRemove.length > 0) {
            await member.roles.remove(rolesToRemove);
        }

        const roleIndexToAdd = warnCount - 1;
        
        if (roleIndexToAdd >= 0 && roleIndexToAdd < configuredRoles.length) {
            const roleIdToAdd = configuredRoles[roleIndexToAdd];
            const roleObj = interaction.guild.roles.cache.get(roleIdToAdd);
            
            if (roleObj) {
                await member.roles.add(roleObj);
            }
        }
    } catch (roleError) {
      console.error('❌ Error managing warn roles:', roleError);
      roleErrorOccurred = true;
    }

    const warnEmbed = new EmbedBuilder()
      .setColor(0xDE4B52)
      .setDescription(`## <:Moderation:1394887139925426397> Hornet Warn System ${warnCount}/${warnConfig.maxWarns}\n- User: ${member}\n- Reason: ${reason}\n- Moderator: ${executor}`)
      .setThumbnail('https://iili.io/KumNYAb.png')
      .setFooter({
        text: 'Hornet Warn System',
        iconURL: 'https://iili.io/Kl1JfOg.png'
      });

    await interaction.reply({ embeds: [warnEmbed] });
    member.send({ embeds: [warnEmbed] }).catch(() => {});

    if (roleErrorOccurred) {
      await interaction.followUp({
        content: `<a:erro:1419734220191830146> The warn was saved, but I failed to manage the warn roles. Please check my role hierarchy and permissions.`,
        ephemeral: true
      });
    }

    if (warnCount >= warnConfig.maxWarns) {
      
      if (!member.bannable) {
        return interaction.followUp({
          content: `<a:erro:1419734220191830146> I cannot ban this user (they reached the limit of ${warnConfig.maxWarns} warns, but I lack ban permissions or they are higher than me).`,
          ephemeral: true
        });
      }

      const banReason = `Accumulated ${warnCount}/${warnConfig.maxWarns} warns (Automatic Ban)`;

      const dmBanEmbed = new EmbedBuilder()
        .setColor(0xED4245)
        .setDescription(`## <:Moderation:1394887139925426397> Hornet Warn Ban\n- **Reason:** ${banReason}\n- You reached the warning limit and were banned from ${interaction.guild.name}.`)
        .setThumbnail('https://iili.io/KumNYAb.png')
        .setFooter({
          text: 'Hornet Ban System',
          iconURL: 'https://iili.io/Kl1JfOg.png'
        });
      
      await member.send({ embeds: [dmBanEmbed] }).catch(() => {});

      try {
          await member.ban({ reason: banReason });
          await Warn.deleteMany({ guildId: interaction.guild.id, userId: member.id });

          console.log(`🚨 User ${member.user.tag} was banned for reaching warn limit.`);

          const publicBanEmbed = new EmbedBuilder()
            .setColor(0xED4245)
            .setDescription(`## <:Moderation:1394887139925426397> Hornet Warn Ban\n- **User:** ${member}\n- **Reason:** ${banReason}\n- They reached the limit of **${warnConfig.maxWarns}** warns and were banned.`)
            .setThumbnail('https://iili.io/KumNYAb.png')
            .setFooter({
              text: 'Hornet Ban System',
              iconURL: 'https://iili.io/Kl1JfOg.png'
            });

          await interaction.followUp({ embeds: [publicBanEmbed] });
      } catch (err) {
          console.error("Failed to execute auto-ban:", err);
          await interaction.followUp({ content: "<a:erro:1419734220191830146> Failed to execute automatic ban due to an internal error.", ephemeral: true });
      }
    }
  }
};
