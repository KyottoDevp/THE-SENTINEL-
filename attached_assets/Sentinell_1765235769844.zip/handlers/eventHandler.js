const fs = require('fs');
const path = require('path');

function registerEvent(client, filePath) {
    try {
        const event = require(filePath);

        if (typeof event !== 'object' || event === null) {
            console.warn(`[AVISO] O arquivo em ${filePath} não exporta um objeto de evento válido e foi ignorado.`);
            return false;
        }

        if (typeof event.name !== 'string' || !event.name) {
            console.warn(`[AVISO] O evento em ${filePath} não possui uma propriedade 'name' válida.`);
            return false;
        }

        if (typeof event.execute !== 'function') {
            console.warn(`[AVISO] O evento ${event.name} em ${filePath} não possui uma função 'execute'.`);
            return false;
        }

        const listener = (...args) => event.execute(...args, client);

        if (event.once) {
            client.once(event.name, listener);
        } else {
            client.on(event.name, listener);
        }

        return true;
    } catch (error) {
        console.error(`[FALHA CRÍTICA] Erro ao carregar o evento do arquivo ${filePath}:`);
        console.error(error);
        return false;
    }
}

function loadEventsFromDirectory(client, directory, stats) {
    const items = fs.readdirSync(directory, { withFileTypes: true });

    for (const item of items) {
        const fullPath = path.join(directory, item.name);

        if (item.isDirectory()) {
            loadEventsFromDirectory(client, fullPath, stats);
        } else if (item.isFile() && item.name.endsWith('.js')) {
            if (registerEvent(client, fullPath)) {
                stats.loaded++;
            } else {
                stats.failed++;
            }
        }
    }
}

module.exports = (client) => {
    const eventsPath = path.join(__dirname, '../events');
    const stats = { loaded: 0, failed: 0 };

    console.log('=== SISTEMA DE EVENTOS ===');
    console.log('[INICIANDO] Buscando e carregando eventos...');
    console.log(`> Diretório Raiz: ${eventsPath}\n`);

    loadEventsFromDirectory(client, eventsPath, stats);
    
    const total = stats.loaded + stats.failed;
    const successRate = total > 0 ? (stats.loaded / total * 100).toFixed(2) : "0.00";

    console.log('\n[CONCLUSÃO] Processamento de eventos finalizado.');
    console.log('----------------------------------------');

    if (stats.loaded > 0) {
        console.log(`  ● Sucesso: ${stats.loaded} evento(s) carregado(s).`);
    }
    if (stats.failed > 0) {
        console.log(`  ● Falhas: ${stats.failed} evento(s) não foram carregado(s).`);
    }
    
    console.log('----------------------------------------');
    console.log(`[RELATÓRIO FINAL] ${stats.loaded}/${total} eventos operacionais (${successRate}% de sucesso).\n`);
};