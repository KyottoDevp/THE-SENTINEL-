const fs = require('fs');
const path = require('path');
const chalk = require('chalk');

/**
 * Carrega todos os comandos do bot a partir da pasta "commands"
 * Suporta múltiplas categorias e valida a estrutura de cada comando
 * 
 * @param {import('discord.js').Client} client - Cliente do Discord
 */
module.exports = (client) => {
  const commandsPath = path.join(__dirname, '../commands');
  const commandFolders = fs.readdirSync(commandsPath);

  let totalLoaded = 0;

  console.log(chalk.blueBright.bold('\n📁 Carregando comandos...\n'));

  for (const folder of commandFolders) {
    const folderPath = path.join(commandsPath, folder);

    // Ignora arquivos soltos fora das subpastas
    if (!fs.statSync(folderPath).isDirectory()) continue;

    const commandFiles = fs
      .readdirSync(folderPath)
      .filter(file => file.endsWith('.js') || file.endsWith('.ts'));

    for (const file of commandFiles) {
      const fullPath = path.join(folderPath, file);

      try {
        const command = require(fullPath);

        // Suporte a export default (ESModules/TS)
        const cmd = command?.default ?? command;

        if (!cmd || typeof cmd !== 'object') {
          console.warn(chalk.yellow(`⚠️  Arquivo ignorado (não é um objeto): ${file}`));
          continue;
        }

        // Verifica se a estrutura é válida
        const hasData = 'data' in cmd && typeof cmd.data?.name === 'string';
        const hasExecute = typeof cmd.execute === 'function';

        if (!hasData || !hasExecute) {
          console.warn(chalk.yellow(`⚠️  Estrutura inválida no comando: ${file}`));
          continue;
        }

        // Registra o comando na Collection
        client.commands.set(cmd.data.name, cmd);
        totalLoaded++;

        console.log(chalk.green(`✅ Comando carregado: ${chalk.bold(cmd.data.name)} (${folder}/${file})`));

      } catch (error) {
        console.error(chalk.red(`❌ Erro ao carregar comando: ${file}`));
        console.error(error);
      }
    }
  }

  console.log(chalk.blueBright.bold(`\n✅ Total de comandos carregados: ${chalk.bold(totalLoaded)}\n`));
};