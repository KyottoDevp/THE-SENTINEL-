const { Client, Collection, GatewayIntentBits, Partials } = require('discord.js');
const config = require('./config.json');
const connectDB = require('./database/connect');
const Warn = require('./database/models/Warn');
const WarnConfig = require('./database/models/warnConfig');
const VoiceTime = require('./database/models/VoiceTime');

if (!config.token) {
process.exit(1);
}

const client = new Client({
intents: [
GatewayIntentBits.Guilds,
GatewayIntentBits.GuildMessages,
GatewayIntentBits.GuildMembers,
GatewayIntentBits.MessageContent,
GatewayIntentBits.GuildVoiceStates
],
partials: [
Partials.Message,
Partials.Channel,
Partials.GuildMember,
Partials.User
]
});

client.commands = new Collection();
client.cooldowns = new Collection();

try {
require('./handlers/commandHandler')(client);
require('./handlers/eventHandler')(client);
} catch (error) {
process.exit(1);
}

connectDB();

const synchronizeWarnRoles = async (client) => {
for (const guild of client.guilds.cache.values()) {
try {
const warnConfig = await WarnConfig.findOne({ guildId: guild.id });

code
Code
download
content_copy
expand_less
if (!warnConfig || !warnConfig.active || !warnConfig.warnRoles || warnConfig.warnRoles.length === 0) {
    continue;
  }

  const configuredRoleIds = warnConfig.warnRoles;
  const validRoles = [];
  
  for (const roleId of configuredRoleIds) {
    const role = guild.roles.cache.get(roleId);
    if (role) validRoles.push(roleId);
  }

  if (validRoles.length === 0) {
    continue;
  }

  let aggregatedWarns;
  try {
    aggregatedWarns = await Warn.aggregate([
      { $match: { guildId: guild.id } },
      { $group: { _id: '$userId', count: { $sum: 1 } } }
    ]);
  } catch (errDb) {
    continue;
  }

  const warnMap = new Map();
  for (const result of aggregatedWarns) {
    warnMap.set(result._id, result.count);
  }

  const members = await guild.members.fetch().catch(() => null);
  if (!members) {
    continue;
  }

  for (const member of members.values()) {
    if (member.user.bot || member.user.system) continue;

    try {
      const warnCount = warnMap.get(member.id) || 0;
      const rolesToAdd = [];
      const rolesToRemove = [];

      let targetRoleId = null;

      if (warnCount > 0) {
        let roleIndex = warnCount - 1;
        if (roleIndex >= configuredRoleIds.length) {
          roleIndex = configuredRoleIds.length - 1;
        }
        targetRoleId = configuredRoleIds[roleIndex];
      }

      for (const configRoleId of configuredRoleIds) {
        const hasRole = member.roles.cache.has(configRoleId);
        
        if (targetRoleId && configRoleId === targetRoleId) {
          if (!hasRole) {
            rolesToAdd.push(configRoleId);
          }
        } else {
          if (hasRole) {
            rolesToRemove.push(configRoleId);
          }
        }
      }

      if (rolesToRemove.length > 0) {
        await member.roles.remove(rolesToRemove, 'Sincronização automática de warns (Remoção)');
      }

      if (rolesToAdd.length > 0) {
        await member.roles.add(rolesToAdd, 'Sincronização automática de warns (Adição)');
      }

    } catch (innerError) {
      continue;
    }
  }
} catch (guildError) {
  continue;
}

}
};

const checkAndCleanWarnsAdvanced = async () => {
for (const guild of client.guilds.cache.values()) {
try {
const warns = await Warn.find({ guildId: guild.id });
if (!warns || warns.length === 0) continue;

code
Code
download
content_copy
expand_less
const userIds = [...new Set(warns.map(w => w.userId))];
  
  for (const userId of userIds) {
    try {
      const isBanned = await guild.bans.fetch(userId).catch(() => null);
      
      if (isBanned) {
        await Warn.deleteMany({ guildId: guild.id, userId: userId });
      } else {
        const member = await guild.members.fetch(userId).catch(() => null);
        if (!member) {
           continue; 
        }
      }
    } catch (userCheckError) {
      continue;
    }
  }
} catch (guildError) {
  continue;
}

}
};

client.on('voiceStateUpdate', async (oldState, newState) => {
const user = newState.member?.user;
if (!user || user.bot || user.system) return;

if (!oldState.channelId && newState.channelId) {
try {
await VoiceTime.findOneAndUpdate(
{ guildId: newState.guild.id, userId: user.id },
{ $set: { lastJoin: Date.now() } },
{ upsert: true }
);
} catch (err) {
// Silencioso
}
}

if (oldState.channelId && !newState.channelId) {
try {
const doc = await VoiceTime.findOne({ guildId: newState.guild.id, userId: user.id });
if (doc?.lastJoin) {
const tempo = Date.now() - doc.lastJoin;
await VoiceTime.findOneAndUpdate(
{ guildId: newState.guild.id, userId: user.id },
{ $inc: { totalTime: tempo }, $unset: { lastJoin: "" } },
{ upsert: true }
);
}
} catch (err) {
// Silencioso
}
}
});

client.login(config.token).catch(err => {
process.exit(1);
});

client.once('ready', async () => {
await synchronizeWarnRoles(client);
await checkAndCleanWarnsAdvanced();

setInterval(async () => {
await synchronizeWarnRoles(client);
await checkAndCleanWarnsAdvanced();
}, 60 * 60 * 1000);

setInterval(async () => {
for (const guild of client.guilds.cache.values()) {
const voiceMembers = guild.members.cache.filter(
m => m.voice.channelId && !m.user.bot && !m.user.system
);

for (const member of voiceMembers.values()) {
    try {
      const doc = await VoiceTime.findOne({ guildId: guild.id, userId: member.id });

      if (!doc) {
        await VoiceTime.create({
          guildId: guild.id,
          userId: member.id,
          lastJoin: Date.now()
        });
        continue;
      }

      if (doc.lastJoin) {
        const diff = Date.now() - doc.lastJoin;

        if (diff >= 60 * 1000) {
          await VoiceTime.findOneAndUpdate(
            { guildId: guild.id, userId: member.id },
            { $inc: { totalTime: 60 * 1000 }, $set: { lastJoin: Date.now() } }
          );
        }
      } else {
        await VoiceTime.findOneAndUpdate(
          { guildId: guild.id, userId: member.id },
          { $set: { lastJoin: Date.now() } },
          { upsert: true }
        );
      }
    } catch (err) {
      // Silencioso
    }
  }
}

}, 60 * 1000);
});