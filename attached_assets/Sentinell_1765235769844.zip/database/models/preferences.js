// @file database/models/preferences.js
const mongoose = require('mongoose');

const preferenceSchema = new mongoose.Schema({
    userId: {
        type: String,
        required: true,
        unique: true, // Garante que cada usuário tenha apenas uma preferência
    },
    language: {
        type: String,
        required: true, // O código do idioma, ex: 'pt', 'en', 'es'
    },
});

module.exports = mongoose.model('Preference', preferenceSchema);
