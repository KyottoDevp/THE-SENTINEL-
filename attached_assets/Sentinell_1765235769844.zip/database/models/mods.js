const mongoose = require('mongoose');

const modSchema = new mongoose.Schema({
  guildId: { type: String, required: true },
  title: { type: String, required: true, unique: true },
  description: { type: String, required: true },
  link: { type: String },
  jsonEmbed: { type: String },
  emoji: { type: String }
}, { timestamps: true });

module.exports = mongoose.model('Mod', modSchema);