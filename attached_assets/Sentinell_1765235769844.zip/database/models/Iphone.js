const mongoose = require('mongoose');

const GlePortSchema = new mongoose.Schema({
  guildId: { type: String, required: true },
  title: { type: String, required: true, unique: true, trim: true, maxLength: 100 },
  description: { type: String, trim: true, maxLength: 1000 },
  link: { type: String, trim: true },
  jsonEmbed: { type: String },
  emoji: { type: String, trim: true }
}, { timestamps: true });

module.exports = mongoose.model('GlePort', GlePortSchema);