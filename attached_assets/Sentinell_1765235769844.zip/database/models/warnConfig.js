const mongoose = require('mongoose');

const warnConfigSchema = new mongoose.Schema({
    guildId: { 
        type: String, 
        required: true, 
        unique: true 
    },
    warnRoles: { 
        type: [String], 
        default: [] 
    },
    maxWarns: { 
        type: Number, 
        default: 3 
    },
    active: {
        type: Boolean,
        default: false
    }
});

module.exports = mongoose.model('WarnConfig', warnConfigSchema);