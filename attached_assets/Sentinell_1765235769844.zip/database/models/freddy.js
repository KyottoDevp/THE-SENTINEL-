const { model, Schema } = require('mongoose');

const freddySchema = new Schema({
  guildId: { type: String, required: true },
  title: { type: String, required: true, unique: true },
  description: { type: String },
  link: { type: String },
  jsonEmbed: { type: String },
  emoji: { type: String }
}, { timestamps: true });

module.exports = model('FreddyPort', freddySchema);