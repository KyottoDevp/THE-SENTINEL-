const mongoose = require('mongoose');

// Este sub-esquema define a estrutura para customizar um componente individual (botão ou menu)
const componentCustomizationSchema = new mongoose.Schema({
    // O customId original do componente para identificá-lo de forma única.
    originalId: {
        type: String,
        required: true,
    },
    // O novo texto para a label de um botão.
    customLabel: {
        type: String,
        required: false, // Opcional, usado apenas para botões.
    },
    // O novo texto para o placeholder de um menu de seleção.
    customPlaceholder: {
        type: String,
        required: false, // Opcional, usado apenas para menus.
    },
}, {
    _id: false // Desativa a criação de _id para estes subdocumentos.
});

// Este sub-esquema agrupa todas as customizações para um painel.
const customDataSchema = new mongoose.Schema({
    // O conteúdo principal do painel (descrição ou JSON completo do container).
    content: {
        type: String,
        default: null,
    },
    // A URL para a imagem da thumbnail.
    thumbnailUrl: {
        type: String,
        default: null,
    },
    // A cor de destaque (accent color) do container.
    accentColor: {
        type: Number,
        default: null,
    },
    // Uma lista de todos os componentes (botões/menus) que foram customizados.
    components: [componentCustomizationSchema],
}, {
    _id: false
});

// O esquema principal que será armazenado na coleção.
const painelCustomizacaoSchema = new mongoose.Schema({
    // ID do servidor (guild) ao qual esta customização pertence.
    guildId: {
        type: String,
        required: true,
        index: true, // Indexado para buscas rápidas.
    },
    // Um identificador único para o painel que está sendo customizado (ex: 'hub_silksong_skins').
    panelId: {
        type: String,
        required: true,
        index: true, // Indexado para buscas rápidas.
    },
    // O objeto que contém todos os dados da customização.
    customData: {
        type: customDataSchema,
        default: () => ({ components: [] }), // Garante que customData e components existam.
    },
}, {
    // Adiciona automaticamente os campos createdAt e updatedAt.
    timestamps: true,
});

// Cria um índice composto e único para garantir que só exista UMA customização
// por painel em cada servidor. Isso previne dados duplicados.
painelCustomizacaoSchema.index({ guildId: 1, panelId: 1 }, { unique: true });

// Exporta o modelo para que ele possa ser usado em outras partes do seu código.
module.exports = mongoose.model('PainelCustomizacao', painelCustomizacaoSchema);