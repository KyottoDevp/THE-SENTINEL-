const { Schema, model } = require('mongoose');

const warnSchema = new Schema({
  guildId: {
    type: String,
    required: true
  },
  userId: {
    type: String,
    required: true
  },
  moderatorId: {
    type: String,
    required: true
  },
  reason: {
    type: String,
    required: true
  },
  timestamp: {
    type: Date,
    default: Date.now
  },
  expiresAt: {
    type: Date,
    default: null
  },
  active: {
    type: Boolean,
    default: true // Indica se o warn ainda está ativo
  }
});

// Index para melhorar buscas por guildId + userId
warnSchema.index({ guildId: 1, userId: 1 });

module.exports = model('Warn', warnSchema);
