const mongoose = require('mongoose');

const economiaSchema = new mongoose.Schema({
  guildId: { type: String, required: true },
  userId: { type: String, required: true },
  userName: { type: String, required: true },
  guildName: { type: String, required: true },
  recompensa: { type: Number, required: true, default: 0 },
  streak: { type: Number, default: 1 },
  lastClaim: { type: Date, default: null },
  createdAt: { type: Date, default: Date.now }
}, { timestamps: true });

module.exports = mongoose.model('Economia', economiaSchema);