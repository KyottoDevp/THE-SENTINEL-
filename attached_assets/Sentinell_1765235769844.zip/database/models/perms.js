const { Schema, model } = require('mongoose');

// Define a estrutura para armazenar os IDs dos usuários permitidos
const permSchema = new Schema({
    userId: {
        type: String,
        required: true,
        unique: true // Garante que um usuário não seja adicionado mais de uma vez
    }
});

// Cria e exporta o modelo com base no schema
module.exports = model('PermittedUsers', permSchema);
