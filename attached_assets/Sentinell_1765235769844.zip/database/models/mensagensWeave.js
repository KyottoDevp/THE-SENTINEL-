const { Schema, model } = require('mongoose');

const mensagemWeaveSchema = new Schema({
  guildId: { type: String, required: true, unique: true },
  jsonMessage: { type: String, required: true }
}, { timestamps: true });

module.exports = model('MensagemWeave', mensagemWeaveSchema);