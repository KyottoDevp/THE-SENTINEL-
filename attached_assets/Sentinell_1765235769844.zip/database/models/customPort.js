// Arquivo: ../database/models/customPort.js

const mongoose = require('mongoose');

const customPortSchema = new mongoose.Schema({
    guildId: {
        type: String,
        required: true
    },
    // Categoria do item, corresponde ao 'id' do botão no modelo GuildHubConfig
    // Ex: 'custom-1', 'custom-2'
    category: {
        type: String,
        required: true
    },
    title: {
        type: String,
        required: true,
        maxLength: 100
    },
    description: {
        type: String,
        required: false,
        maxLength: 1000
    },
    link: {
        type: String,
        required: false
    },
    jsonEmbed: {
        type: String,
        required: false
    },
    emoji: {
        type: String,
        required: false
    },
    position: {
        type: Number,
        required: true
    }
});

// Índice para otimizar a busca de itens por servidor e categoria
customPortSchema.index({ guildId: 1, category: 1 });
// Índice para garantir que não haja títulos duplicados na mesma categoria
customPortSchema.index({ guildId: 1, category: 1, title: 1 }, { unique: true });

module.exports = mongoose.model('CustomPort', customPortSchema);