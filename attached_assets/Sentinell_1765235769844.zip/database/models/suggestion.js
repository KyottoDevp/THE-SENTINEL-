const mongoose = require('mongoose');

const suggestionSchema = new mongoose.Schema({
    guildId: {
        type: String,
        required: true
    },
    userId: {
        type: String,
        required: true
    },
    messageId: { // ID da mensagem enviada no canal de sugestões
        type: String,
        default: null
    },
    channelId: { // ID do canal onde a mensagem está
        type: String,
        default: null
    },
    content: {
        type: String,
        required: true
    },
    status: {
        type: String,
        enum: ['Pending', 'Approved', 'Rejected'],
        default: 'Pending'
    },
    moderatorId: { // ID do staff que aprovou/recusou
        type: String,
        default: null
    },
    timestamp: {
        type: Date,
        default: Date.now
    },
    // Array para armazenar quem votou e o tipo de voto
    voters: [{
        userId: {
            type: String,
            required: true
        },
        voteType: {
            type: String,
            enum: ['up', 'down'], // 'up' para positivo, 'down' para negativo (se implementar)
            required: true
        },
        timestamp: {
            type: Date,
            default: Date.now
        }
    }]
});

module.exports = mongoose.model('Suggestion', suggestionSchema);