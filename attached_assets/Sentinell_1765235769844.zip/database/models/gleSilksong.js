const mongoose = require('mongoose');

const GlePortSilksongSchema = new mongoose.Schema({
  guildId: { type: String, required: true },
  title: { type: String, required: true, unique: true, maxLength: 100 },
  description: { type: String, maxLength: 1000 },
  jsonEmbed: { type: String, default: null },
  link: { type: String, default: null },
  emoji: { type: String, default: null }
}, { timestamps: true });

module.exports = mongoose.model('GlePortSilksong', GlePortSilksongSchema);