const mongoose = require('mongoose');

const dannMessageSchema = new mongoose.Schema({
  guildId: { type: String, required: true, unique: true },
  jsonMessage: { type: String, required: true }
}, { timestamps: true });

module.exports = mongoose.model('MensagemDann', dannMessageSchema);