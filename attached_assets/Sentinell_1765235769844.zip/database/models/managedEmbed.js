const { Schema, model } = require('mongoose');

const managedEmbedSchema = new Schema({
  guildId: { type: String, required: true },
  type: { type: String, required: true, enum: ['mods', 'skins', 'saves'] },
  game: { type: String, required: true, enum: ['silksong', 'knight'] },
  channelId: { type: String },
  messageId: { type: String }
}, { timestamps: true });

module.exports = model('ManagedEmbed', managedEmbedSchema);