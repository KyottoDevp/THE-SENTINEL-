const { Schema, model } = require('mongoose');

const knightSkinSchema = new Schema({
  guildId: { type: String, required: true },
  title: { type: String, required: true, unique: true },
  description: { type: String },
  link: { type: String },
  jsonEmbed: { type: String },
  emoji: { type: String }
}, { timestamps: true });

module.exports = model('KnightSkin', knightSkinSchema);