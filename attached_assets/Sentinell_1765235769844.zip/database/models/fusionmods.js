const mongoose = require('mongoose');

const universalSchema = new mongoose.Schema({
  guildId: { type: String, required: true },
  title: { type: String, required: true },
  description: { type: String },
  link: { type: String },
  jsonEmbed: { type: String },
  emoji: { type: String },
  position: { type: Number, default: 0 }
}, { timestamps: true });

module.exports = mongoose.model('Universal', universalSchema);