const { Schema, model } = require('mongoose');

const BanSchema = new Schema({
  userId: { type: String, required: true },
  username: { type: String, required: true },
  tag: { type: String, required: true },
  executorId: { type: String, required: true },
  executorTag: { type: String, required: true },
  guildId: { type: String, required: true },
  guildName: { type: String, required: true },
  reason: { type: String, required: true },
  bannedAt: { type: Date, default: Date.now }
});

module.exports = model('Ban', BanSchema);