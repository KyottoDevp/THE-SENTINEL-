const { Schema, model } = require('mongoose');

const skinSchema = new Schema({
  guildId: { type: String, required: true },
  title: { type: String, required: true, unique: true },
  description: { type: String, required: true },
  link: { type: String },
  jsonEmbed: { type: String },
  emoji: { type: String }
}, { timestamps: true });

module.exports = model('Skin', skinSchema);