const mongoose = require('mongoose');

const universalKnightSchema = new mongoose.Schema({
    title: {
        type: String,
        required: true
    },
    description: {
        type: String,
        required: false
    },
    link: {
        type: String,
        required: false
    },
    jsonEmbed: {
        type: String,
        required: false
    },
    emoji: {
        type: String,
        required: false
    },
    position: {
        type: Number,
        required: false,
        default: 0
    }
});

module.exports = mongoose.model('UniversalKnight', universalKnightSchema);