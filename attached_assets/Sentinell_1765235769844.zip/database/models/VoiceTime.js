// database/models/VoiceTime.js
const { Schema, model } = require('mongoose');

const voiceTimeSchema = new Schema({
    guildId: String,
    userId: String,
    totalTime: { type: Number, default: 0 }, // em ms
    lastJoin: { type: Number, default: null }
});

module.exports = model('VoiceTime', voiceTimeSchema);