const { Schema, model } = require('mongoose');

const permissionRoleSchema = new Schema({
  guildId: { type: String, required: true },
  roleIds: { type: [String], default: [] } // IDs dos cargos autorizados
});

module.exports = model('PermissionRole', permissionRoleSchema);