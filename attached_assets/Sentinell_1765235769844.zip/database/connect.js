/**
 * database/connect.js
 * Conexão simples com MongoDB via Mongoose (CommonJS)
 */

const mongoose = require('mongoose');
const config = require('../config.json');

// ===== Utilitário de log minimalista =====
function log(message) {
  console.log(message);
}

// ===== Validação de configuração =====
function validateConfig() {
  if (!config.mongoURL || typeof config.mongoURL !== 'string') {
    throw new Error('mongoURL ausente ou inválido em config.json.');
  }
  if (!/^mongodb(\+srv)?:\/\//.test(config.mongoURL)) {
    throw new Error('mongoURL deve começar com mongodb:// ou mongodb+srv://');
  }
}

// ===== Opções =====
function buildOptions() {
  return {
    maxPoolSize: config.mongoMaxPool || 20,
    minPoolSize: config.mongoMinPool || 1,
    serverSelectionTimeoutMS: config.mongoSelectTimeout || 15000,
    socketTimeoutMS: config.mongoSocketTimeout || 30000,
    heartbeatFrequencyMS: config.mongoHeartbeat || 10000,
    connectTimeoutMS: config.mongoConnectTimeout || 15000,
    dbName: config.mongoDbName || undefined,
    tls: config.mongoTLS || undefined,
    replicaSet: config.mongoReplicaSet || undefined,
    autoIndex: config.mongoAutoIndex !== false // true por padrão
  };
}

// ===== Eventos do Mongoose =====
function wireEvents() {
  const conn = mongoose.connection;
  conn.on('connected', () => log('Mongoose conectado.'));
  conn.on('error', (err) => log(`Erro Mongoose: ${err.message}`));
  conn.on('disconnected', () => log('Mongoose desconectado.'));
  conn.on('reconnected', () => log('Mongoose reconectado.'));
}

// ===== Encerramento gracioso =====
function setupShutdown() {
  ['SIGINT', 'SIGTERM', 'SIGHUP'].forEach(sig => {
    process.on(sig, async () => {
      log(`Encerrando conexão MongoDB... (signal: ${sig})`);
      try {
        await mongoose.connection.close(false);
        log('Conexão MongoDB fechada com sucesso.');
      } catch (err) {
        log(`Erro ao fechar conexão: ${err.message}`);
      } finally {
        process.exit(0);
      }
    });
  });
}

// ===== Export principal =====
module.exports = async function initMongo() {
  validateConfig();
  mongoose.set('strictQuery', true);
  wireEvents();
  setupShutdown();

  const options = buildOptions();

  try {
    await mongoose.connect(config.mongoURL, options);
    log('✅ Conexão com MongoDB estabelecida!');
  } catch (error) {
    log(`Falha ao conectar no MongoDB: ${error.message}`);
    throw error;
  }
};