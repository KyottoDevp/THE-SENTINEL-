const fs = require("fs");
const path = require("path");
const { Collection, ActivityType } = require("discord.js");
const connect = require("../database/connect");

async function loadAndSyncCommands(client) {
  client.commands = new Collection();
  const commandsPath = path.join(__dirname, "../commands");
  const commandData = [];

  try {
    const commandFolders = fs.readdirSync(commandsPath);

    for (const folder of commandFolders) {
      const folderPath = path.join(commandsPath, folder);
      const commandFiles = fs
        .readdirSync(folderPath)
        .filter((file) => file.endsWith(".js"));

      for (const file of commandFiles) {
        const filePath = path.join(folderPath, file);
        try {
          const command = require(filePath);
          
          if (command.data && command.execute) {
            client.commands.set(command.data.name, command);
            commandData.push(command.data.toJSON());
            console.log(`✅ Comando carregado: ${command.data.name}`);
          } else {
            console.warn(`⚠️ Comando inválido (falta data ou execute) em: ${filePath}`);
          }
        } catch (err) {
          console.error(`❌ Erro ao carregar comando ${file}:`, err);
        }
      }
    }

    if (commandData.length > 0) {
      await client.application.commands.set(commandData);
      console.log(`🌍 ${commandData.length} Comandos globais sincronizados com sucesso!`);
    } else {
      console.log("ℹ️ Nenhum comando encontrado para sincronizar.");
    }

  } catch (err) {
    console.error("❌ Falha crítica no carregamento ou sincronização de comandos:", err);
  }
}

module.exports = {
  name: "ready",
  once: true,
  async execute(client) {
    if (!client.user) return;

    try {
      await connect();
      console.log("✅ Conexão com MongoDB estabelecida!");
    } catch (err) {
      console.error("❌ Erro ao conectar ao MongoDB:", err);
    }

    await loadAndSyncCommands(client);
    
    // Sistema de cache removido daqui

    const TARGET_GUILD_ID = "1416281196576374836";
    const startTime = Date.now();
    let index = 0;

    setInterval(async () => {
      const guild = client.guilds.cache.get(TARGET_GUILD_ID) || await client.guilds.fetch(TARGET_GUILD_ID).catch(() => null);
      if (!guild) return;

      const memberCount = guild.memberCount;
      const guildName = guild.name;

      const diff = Date.now() - startTime;
      const hours = Math.floor(diff / (1000 * 60 * 60));
      const minutes = Math.floor((diff / (1000 * 60)) % 60);

      const presences = [
        {
          name: "Tecnologia Java Script | Powered by JavaScript",
          type: ActivityType.Playing,
        },
        {
          name: `👥 Monitorando ${memberCount} membros de ${guildName}`,
          type: ActivityType.Watching,
        },
        {
          name: `🔴 Online há ${hours}h ${minutes}min`,
          type: ActivityType.Listening, 
        },
      ];

      client.user.setPresence({
        activities: [presences[index]],
        status: "dnd",
      });

      index = (index + 1) % presences.length;
    }, 10_000);

    console.log(`🤖 Bot iniciado como ${client.user.tag}`);
  },
};
