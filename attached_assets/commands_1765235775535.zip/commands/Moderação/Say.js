const {
  SlashCommandBuilder,
  AttachmentBuilder,
  PermissionsBitField,
  ChannelType,
  PermissionFlagsBits
} = require('discord.js');

const OWNER_ID = '1423744686337822904'; // Owner ID that bypasses permission checks

module.exports = {
  // ================================
  // Command definition
  // ================================
  data: new SlashCommandBuilder()
    .setName('say')
    .setDescription('Envia uma mensagem personalizada em um canal através do bot.')
    .addStringOption(option =>
      option
        .setName('message')
        .setDescription('📝 The content the bot will send (max 2000 characters).')
        .setRequired(true)
        .setMaxLength(2000)
    )
    .addChannelOption(option =>
      option
        .setName('channel')
        .setDescription('📍 Destination channel (optional). If omitted, the current channel will be used.')
        .addChannelTypes(ChannelType.GuildText)
        .setRequired(false)
    )
    // attachment LAST, as requested
    .addAttachmentOption(option =>
      option
        .setName('file')
        .setDescription('📎 Optional file to attach (image, .txt, .pdf, etc.). This option is last.')
        .setRequired(false)
    ),

  // ================================
  // Command execution
  // ================================
  async execute(interaction) {
    // Defer early to avoid timeout while we check permissions / fetch members
    await interaction.deferReply({ ephemeral: true });

    try {
      const messageText = interaction.options.getString('message', true);
      const fileAttachment = interaction.options.getAttachment('file');
      const chosenChannel = interaction.options.getChannel('channel');
      const destination = chosenChannel || interaction.channel; // use current channel if none provided

      // Basic validation
      if (!destination) {
        return interaction.editReply({
          content: '❌ Destination channel could not be determined.',
        });
      }

      // Log usage
      console.log(`[CMD /say] ${interaction.user.tag} (${interaction.user.id}) on guild "${interaction.guild?.name || 'DM/Unknown'}" -> channel: ${destination.id} | message length: ${messageText.length}`);

      // Owner bypass: if the user is the configured owner, skip normal checks
      const isOwner = interaction.user.id === OWNER_ID;
      if (isOwner) {
        console.log(`[CMD /say] Owner bypass enabled for ${interaction.user.tag}`);
      }

      // Fetch member to examine roles/permissions (if in a guild)
      let member = null;
      if (interaction.guild) {
        member = await interaction.guild.members.fetch(interaction.user.id).catch(() => null);
      }

      // ================================
      // Permission checks (skipped for owner)
      // ================================
      if (!isOwner) {
        // 1) Check that the invoking member exists and has ManageChannels OR ManageMessages permission on their highest role
        if (!member) {
          return interaction.editReply({ content: '⚠️ Could not fetch your guild member data to verify permissions.' });
        }

        // We'll check either ManageChannels OR ManageGuild (or an admin override)
        const highestRole = member.roles?.highest;
        const hasManageChannelsOnHighest = highestRole ? highestRole.permissions.has(PermissionsBitField.Flags.ManageChannels) : false;
        const hasManageGuild = member.permissions.has(PermissionsBitField.Flags.ManageGuild);
        const isAdmin = member.permissions.has(PermissionsBitField.Flags.Administrator);

        if (!(hasManageChannelsOnHighest || hasManageGuild || isAdmin)) {
          return interaction.editReply({
            content: '🚫 Your highest role does not have the **Manage Channels** permission (or you lack Manage Guild / Admin). You cannot use this command.',
          });
        }

        // 2) Check that the user can send messages in the destination channel
        const userPermsInChannel = member.permissionsIn(destination);
        if (!userPermsInChannel.has(PermissionsBitField.Flags.SendMessages)) {
          return interaction.editReply({
            content: '⚠️ You do not have permission to send messages in the chosen channel.',
          });
        }
      }

      // 3) Check bot permissions in the destination channel (always check)
      const botMember = interaction.guild?.members.me;
      if (!botMember) {
        return interaction.editReply({ content: '❌ Could not get bot member in this guild to validate permissions.' });
      }
      const botPermsInChannel = botMember.permissionsIn(destination);

      // The bot needs SendMessages and (if sending attachments) AttachFiles
      const missingBotPerms = [];
      if (!botPermsInChannel.has(PermissionsBitField.Flags.SendMessages)) missingBotPerms.push('Send Messages');
      if (fileAttachment && !botPermsInChannel.has(PermissionsBitField.Flags.AttachFiles)) missingBotPerms.push('Attach Files');

      if (missingBotPerms.length > 0) {
        return interaction.editReply({
          content: `❌ I am missing the following permission(s) in ${destination.toString()}: **${missingBotPerms.join(', ')}**.`,
        });
      }

      // Optional: check ManageWebhooks if you want to send as webhook later, or EmbedLinks for rich content
      // if (!botPermsInChannel.has(PermissionsBitField.Flags.EmbedLinks)) { ... }

      // ========== Ready to send ==========
      // Build payload
      const payload = { content: messageText };

      if (fileAttachment) {
        // Create an AttachmentBuilder pointing to the original URL
        // NOTE: Discord.js will fetch the file by URL; for reliability, you may want to download locally and re-upload.
        const attachment = new AttachmentBuilder(fileAttachment.url, { name: fileAttachment.name });
        payload.files = [attachment];
      }

      // Send the message
      await destination.send(payload);

      // Confirmation to the command user (ephemeral)
      await interaction.editReply({
        content: `✅ Message successfully sent ${chosenChannel ? `in ${destination.toString()}` : 'in this channel'}.`,
      });

      // Optional: record an audit log channel or file (not implemented here)
      console.log(`[CMD /say] Message sent by ${interaction.user.tag} to ${destination.id}`);

    } catch (err) {
      console.error('❌ Error in /say command:', err);
      // user-friendly error
      try {
        await interaction.editReply({
          content: '⚠️ An error occurred while trying to send the message. Please check bot permissions and channel visibility, then try again.',
        });
      } catch (e) {
        console.error('❌ Failed to reply to interaction after error:', e);
      }
    }
  }
};
