const { 
    SlashCommandBuilder, 
    PermissionFlagsBits, 
    ActionRowBuilder, 
    StringSelectMenuBuilder,
    ContainerBuilder,
    SectionBuilder,
    ThumbnailBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    MessageFlags
} = require('discord.js');

const WarnConfig = require('../../database/models/warnConfig.js');

const THUMBNAIL_URL = 'https://iili.io/f2ePUAJ.png';

module.exports = {
    data: new SlashCommandBuilder()
        .setName('warnconfigurar')
        .setDescription('Configura o sistema de avisos e punições automáticas.')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    async execute(interaction) {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });

        let config = await WarnConfig.findOne({ guildId: interaction.guild.id });
        if (!config) {
            config = new WarnConfig({
                guildId: interaction.guild.id,
                warnRoles: [],
                maxWarns: 3,
                active: false
            });
            await config.save();
        }

        const isActive = config.active;
        const statusIcon = isActive ? '<a:Grenn:1443742656462061568>' : '<a:Red:1443742654650388501>';
        const statusText = isActive ? 'Sistema Ativo' : 'Sistema Inativo';
        
        const limitText = `**${config.maxWarns}** Aviso(s)`;
        
        let roleListDisplay = 'Nenhum cargo de punição configurado.';
        let roleCount = 0;

        if (config.warnRoles && config.warnRoles.length > 0) {
            roleCount = config.warnRoles.length;
            roleListDisplay = config.warnRoles.map((roleId, index) => {
                const role = interaction.guild.roles.cache.get(roleId);
                const roleName = role ? role.toString() : '`⚠️ Cargo Deletado`';
                return `> **${index + 1}º Aviso:** ${roleName}`;
            }).join('\n');
        }

        let integrityNote = "";
        if (roleCount !== config.maxWarns && roleCount > 0) {
            integrityNote = `\n\n⚠️ **Nota de Integridade:** Você tem **${roleCount}** cargo(s) configurado(s) para um limite de **${config.maxWarns}** aviso(s). Recomenda-se ajustar para que a quantidade seja igual.`;
        }

        const menuPrincipal = new StringSelectMenuBuilder()
            .setCustomId('warn_config_menu_principal')
            .setPlaceholder('Selecione uma opção de configuração...')
            .addOptions([
                {
                    label: 'Configurar Cargos de Punição',
                    description: 'Defina a hierarquia de cargos para cada aviso.',
                    value: 'warn_config_opcao_cargos',
                    emoji: '<:icon_moderation:1441118756678930614>'
                },
                {
                    label: 'Definir Limite de Avisos',
                    description: 'Estabeleça o limite para o banimento automático.',
                    value: 'warn_config_opcao_limite',
                    emoji: '<:icon_settings:1441118761628467230>'
                }
            ]);

        const container = new ContainerBuilder()
            .setAccentColor(0x5865F2)
            .addSectionComponents(
                new SectionBuilder()
                    .setThumbnailAccessory(new ThumbnailBuilder().setURL(THUMBNAIL_URL))
                    .addTextDisplayComponents(
                        new TextDisplayBuilder()
                            .setContent(`## <:icon_settings:1441118761628467230> Sentinel System | Configuração de Warn\n\nBem-vindo ao painel de administração do módulo de Punições. Este sistema oferece controle total sobre a automação de moderação, permitindo definir escalas de punição progressivas e limites de tolerância.\n\n### 📊 Diagnóstico do Sistema\n\n> - **Estado Operacional:** ${statusIcon} ${statusText}\n> - **Limite de Banimento:** ${limitText}\n\n**Escala de Punição Atual:**\n${roleListDisplay}${integrityNote}\n\nUtilize o menu abaixo para navegar entre as categorias de configuração e ajustar o comportamento do sistema.`)
                    )
            )
            .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small))
            .addActionRowComponents(new ActionRowBuilder().addComponents(menuPrincipal));

        await interaction.editReply({
            components: [container],
            flags: MessageFlags.IsComponentsV2
        });
    }
};