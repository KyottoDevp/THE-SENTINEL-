const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const Mute = require('../../database/models/Mute');
const ms = require('ms');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('silenciar')
    .setDescription('Silencia um usuário no servidor por um tempo determinado.')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('User to mute')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('reason')
        .setDescription('Reason for the mute')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('duration')
        .setDescription('Mute duration (example: 10m, 1h, 1d)')
        .setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });

    const user = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason');
    const durationStr = interaction.options.getString('duration');
    const guild = interaction.guild;
    const executor = interaction.member;
    const botMember = guild.members.me;

    const footerText = "Hornet Mute System";
    const footerIcon = "https://iili.io/Kl1JfOg.png";
    const thumbUrl = "https://iili.io/KumNYAb.png";
    const errorEmoji = "<a:off:1419752572264251502>";

    // Fetch target member
    const member = await guild.members.fetch(user.id).catch(() => null);
    if (!member) {
      const embed = new EmbedBuilder()
        .setColor(0xFF0000)
        .setThumbnail(thumbUrl)
        .setDescription(`## ${errorEmoji} Hornet System Mute\n- User not found in the server.`)
        .setFooter({ text: footerText, iconURL: footerIcon });
      return interaction.editReply({ embeds: [embed] });
    }

    // Executor permissions
    if (!executor.permissions.has(PermissionFlagsBits.ModerateMembers)) {
      const embed = new EmbedBuilder()
        .setColor(0xFF0000)
        .setThumbnail(thumbUrl)
        .setDescription(`## ${errorEmoji} Hornet System Mute\n- You do not have permission to mute members.`)
        .setFooter({ text: footerText, iconURL: footerIcon });
      return interaction.editReply({ embeds: [embed] });
    }

    // Bot permissions
    if (!botMember.permissions.has(PermissionFlagsBits.ModerateMembers)) {
      const embed = new EmbedBuilder()
        .setColor(0xFF0000)
        .setThumbnail(thumbUrl)
        .setDescription(`## ${errorEmoji} Hornet System Mute\n- I do not have sufficient permissions to mute this user.`)
        .setFooter({ text: footerText, iconURL: footerIcon });
      return interaction.editReply({ embeds: [embed] });
    }

    // Bot hierarchy
    if (member.roles.highest.position >= botMember.roles.highest.position) {
      const embed = new EmbedBuilder()
        .setColor(0xFF0000)
        .setThumbnail(thumbUrl)
        .setDescription(`## ${errorEmoji} Hornet System Mute\n- Cannot execute this action due to role hierarchy.\n- The user's highest role is equal or higher than mine.`)
        .setFooter({ text: footerText, iconURL: footerIcon });
      return interaction.editReply({ embeds: [embed] });
    }

    // Executor hierarchy
    if (!executor.permissions.has(PermissionFlagsBits.Administrator) && executor.roles.highest.position <= member.roles.highest.position) {
      const embed = new EmbedBuilder()
        .setColor(0xFF0000)
        .setThumbnail(thumbUrl)
        .setDescription(`## ${errorEmoji} Hornet System Mute\n- You cannot mute a user with an equal or higher role than yours.`)
        .setFooter({ text: footerText, iconURL: footerIcon });
      return interaction.editReply({ embeds: [embed] });
    }

    // Validate duration
    const durationMs = ms(durationStr);
    if (!durationMs || durationMs > 28 * 24 * 60 * 60 * 1000) {
      const embed = new EmbedBuilder()
        .setColor(0xFF0000)
        .setThumbnail(thumbUrl)
        .setDescription(`## ${errorEmoji} Hornet System Mute\n- Invalid duration. Use: \`10m\`, \`1h\`, \`2d\` and maximum \`28d\`.`)
        .setFooter({ text: footerText, iconURL: footerIcon });
      return interaction.editReply({ embeds: [embed] });
    }

    try {
      // Apply mute
      await member.timeout(durationMs, reason);

      const endTime = new Date(Date.now() + durationMs);
      const timestampUnix = Math.floor(endTime.getTime() / 1000);

      // Save in DB
      await Mute.create({
        guildId: guild.id,
        userId: member.id,
        moderatorId: interaction.user.id,
        reason,
        endAt: endTime,
      });

      // DM user
      const dmEmbed = new EmbedBuilder()
        .setColor(3447003)
        .setThumbnail(thumbUrl)
        .setDescription(
          `## <:Icon_Moderation:1427138768338681856> Hornet System Mute\n` +
          `- **User:** ${user.tag}\n` +
          `- **Reason:** ${reason}\n` +
          `- **Mute ends:** <t:${timestampUnix}:R>`
        )
        .setFooter({ text: footerText, iconURL: footerIcon });
      await user.send({ embeds: [dmEmbed] }).catch(() => {});

      // Public confirmation
      const publicEmbed = new EmbedBuilder()
        .setColor(3447003)
        .setThumbnail(thumbUrl)
        .setDescription(
          `## <:Icon_Moderation:1427138768338681856> Hornet System Mute\n` +
          `- **User:** ${user.tag}\n` +
          `- **Reason:** ${reason}\n` +
          `- **Mute ends:** <t:${timestampUnix}:R>`
        )
        .setFooter({ text: footerText, iconURL: footerIcon });

      await interaction.editReply({ content: null, embeds: [publicEmbed], ephemeral: false });

    } catch (err) {
      console.error("Error muting user:", err);
      const embed = new EmbedBuilder()
        .setColor(0xFF0000)
        .setThumbnail(thumbUrl)
        .setDescription(`## ${errorEmoji} Hornet System Mute\n- An error occurred while trying to mute the user.`)
        .setFooter({ text: footerText, iconURL: footerIcon });
      return interaction.editReply({ embeds: [embed] });
    }
  }
};