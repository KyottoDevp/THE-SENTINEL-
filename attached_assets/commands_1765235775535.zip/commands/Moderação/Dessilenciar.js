const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const Mute = require('../../database/models/Mute');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unmute')
    .setDescription('Remove o silenciamento (timeout) de um usuário no servidor.')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('User to unmute')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('reason')
        .setDescription('Reason for unmute')
        .setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });

    const user = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason');
    const guild = interaction.guild;
    const executor = interaction.member;
    const botMember = guild.members.me;

    const footerText = "Hornet Unmute System";
    const footerIcon = "https://iili.io/Kl1JfOg.png";
    const thumbUrl = "https://iili.io/KumNYAb.png";
    const errorEmoji = "<a:off:1419752572264251502>";

    // Fetch target member
    const member = await guild.members.fetch(user.id).catch(() => null);
    if (!member) {
      const embed = new EmbedBuilder()
        .setColor(0xFF0000)
        .setThumbnail(thumbUrl)
        .setDescription(`## ${errorEmoji} Hornet System Unmute\n- User not found in the server.`)
        .setFooter({ text: footerText, iconURL: footerIcon });
      return interaction.editReply({ embeds: [embed] });
    }

    // Executor permissions
    if (!executor.permissions.has(PermissionFlagsBits.ModerateMembers)) {
      const embed = new EmbedBuilder()
        .setColor(0xFF0000)
        .setThumbnail(thumbUrl)
        .setDescription(`## ${errorEmoji} Hornet System Unmute\n- You do not have permission to unmute members.`)
        .setFooter({ text: footerText, iconURL: footerIcon });
      return interaction.editReply({ embeds: [embed] });
    }

    // Bot permissions
    if (!botMember.permissions.has(PermissionFlagsBits.ModerateMembers)) {
      const embed = new EmbedBuilder()
        .setColor(0xFF0000)
        .setThumbnail(thumbUrl)
        .setDescription(`## ${errorEmoji} Hornet System Unmute\n- I do not have sufficient permissions to unmute this user.`)
        .setFooter({ text: footerText, iconURL: footerIcon });
      return interaction.editReply({ embeds: [embed] });
    }

    // Bot hierarchy
    if (member.roles.highest.position >= botMember.roles.highest.position) {
      const embed = new EmbedBuilder()
        .setColor(0xFF0000)
        .setThumbnail(thumbUrl)
        .setDescription(`## ${errorEmoji} Hornet System Unmute\n- Cannot execute this action due to role hierarchy.`)
        .setFooter({ text: footerText, iconURL: footerIcon });
      return interaction.editReply({ embeds: [embed] });
    }

    // Executor hierarchy
    if (!executor.permissions.has(PermissionFlagsBits.Administrator) && executor.roles.highest.position <= member.roles.highest.position) {
      const embed = new EmbedBuilder()
        .setColor(0xFF0000)
        .setThumbnail(thumbUrl)
        .setDescription(`## ${errorEmoji} Hornet System Unmute\n- You cannot unmute a user with an equal or higher role than yours.`)
        .setFooter({ text: footerText, iconURL: footerIcon });
      return interaction.editReply({ embeds: [embed] });
    }

    try {
      // Remove mute (timeout)
      await member.timeout(null, reason); // null removes the timeout

      // Remove from database
      await Mute.findOneAndDelete({ guildId: guild.id, userId: member.id });

      // DM user
      const dmEmbed = new EmbedBuilder()
        .setColor(3447003)
        .setThumbnail(thumbUrl)
        .setDescription(
          `## <:protection:1416693208280203264> Hornet System Unmute\n` +
          `- **User:** ${user.tag}\n` +
          `- **Reason:** ${reason}`
        )
        .setFooter({ text: footerText, iconURL: footerIcon });
      await user.send({ embeds: [dmEmbed] }).catch(() => {});

      // Public confirmation
      const publicEmbed = new EmbedBuilder()
        .setColor(3447003)
        .setThumbnail(thumbUrl)
        .setDescription(
          `## <:protection:1416693208280203264> Hornet System Unmute\n` +
          `- **User:** ${user.tag}\n` +
          `- **Reason:** ${reason}`
        )
        .setFooter({ text: footerText, iconURL: footerIcon });

      await interaction.editReply({ content: null, embeds: [publicEmbed], ephemeral: false });

    } catch (err) {
      console.error("Error unmuting user:", err);
      const embed = new EmbedBuilder()
        .setColor(0xFF0000)
        .setThumbnail(thumbUrl)
        .setDescription(`## ${errorEmoji} Hornet System Unmute\n- An error occurred while trying to unmute the user.`)
        .setFooter({ text: footerText, iconURL: footerIcon });
      return interaction.editReply({ embeds: [embed] });
    }
  }
};