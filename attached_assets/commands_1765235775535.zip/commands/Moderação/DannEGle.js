const {
    SlashCommandBuilder,
    ActionRowBuilder,
    StringSelectMenuBuilder,
    ContainerBuilder,
    SectionBuilder,
    TextDisplayBuilder,
    ThumbnailBuilder,
    SeparatorBuilder,
    MessageFlags
} = require('discord.js');
const PermittedUsers = require('../../database/models/perms.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('painel-gerenciamento-hk')
        .setDescription('Abre o painel administrativo para gerenciar os Ports de Hollow Knight.'),

    async execute(interaction) {
        await interaction.deferReply({
            flags: MessageFlags.Ephemeral
        });

        // 1. Verificação de Permissão
        const userPerm = await PermittedUsers.findOne({
            userId: interaction.user.id
        });
        if (!userPerm) {
            const noPermContainer = new ContainerBuilder()
                .setAccentColor(0xed4245)
                .addSectionComponents(
                    new SectionBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(
                            '## Acesso Negado\n\n' +
                            'Você não tem permissão para usar este comando.\n\n' +
                            '*Contate um administrador do sistema para solicitar acesso.*'
                        )
                    )
                );

            return interaction.editReply({
                components: [noPermContainer],
                flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2
            });
        }

        // 2. Descrição Conforme Solicitado
        const descricao =
            `## Painel Administrativo | Hollow Knight Ports\n\n` +
            `- Bem-vindo, **${interaction.user.username}**. Esta é a sua interface dedicada ao gerenciamento das compilações de Hollow Knight.\n\n` +
            `- Este painel centraliza a administração das diferentes versões, permitindo um controle preciso sobre as distribuições para cada plataforma (iOS e Android).\n\n` +
            `- Para começar, selecione a categoria que deseja gerenciar no menu abaixo.`;


        // 3. Menu de Seleção
        const menuOptions = [{
            label: 'GLE Ports',
            description: 'Gerenciar versões para iOS.',
            value: 'gle',
        }, {
            label: 'Dann Cooper Port',
            description: 'Gerenciar versões para Android.',
            value: 'dann',
        }, ];

        const selectMenu = new StringSelectMenuBuilder()
            .setCustomId('selecao_principal_ports_knight')
            .setPlaceholder('Selecione uma categoria para gerenciar...')
            .addOptions(menuOptions);

        const row = new ActionRowBuilder().addComponents(selectMenu);

        // 4. Construção do Container V2
        const painelContainer = new ContainerBuilder()
           .setAccentColor(0x00BFFF)   
            .addSectionComponents(
                new SectionBuilder()
                .setThumbnailAccessory(new ThumbnailBuilder().setURL('https://i.ibb.co/GQstQj4G/Rounded-20251010-163901.png'))
                .addTextDisplayComponents(new TextDisplayBuilder().setContent(descricao))
            )
            .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
            .addActionRowComponents(row);

        // 5. Resposta
        await interaction.editReply({
            components: [painelContainer],
            flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
        });
    },
};