const {
    SlashCommandBuilder,
    ActionRowBuilder,
    StringSelectMenuBuilder,
    ContainerBuilder,
    SectionBuilder,
    TextDisplayBuilder,
    ThumbnailBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    MessageFlags,
    PermissionFlagsBits
} = require('discord.js');

const Warn = require('../../database/models/Warn.js');
const WarnConfig = require('../../database/models/warnConfig.js');
const PermittedUsers = require('../../database/models/perms.js');
const config = require('../../config.json');

const THUMBNAIL_URL = 'https://iili.io/fBem8MJ.png';
const WARNING_ICON_URL = 'https://iili.io/f2ePUAJ.png';

module.exports = {
    data: new SlashCommandBuilder()
        .setName('warnpainel')
        .setDescription('Exibe o painel para gerenciar os avisos dos usuários.'),

    async execute(interaction) {
        await interaction.deferReply({
            flags: MessageFlags.Ephemeral
        });

        const guild = interaction.guild;
        const member = interaction.member;

        const warnConfig = await WarnConfig.findOne({ guildId: guild.id });

        // Verifica se a configuração existe, se está ativa E se há cargos configurados
        // Essa verificação garante que o sistema de cargos (exigido pelo dev) esteja pronto
        const isConfigured = warnConfig && warnConfig.active && warnConfig.warnRoles && warnConfig.warnRoles.length > 0;

        if (!isConfigured) {
            const containerConfigError = new ContainerBuilder()
                .setAccentColor(0xFEE75C)
                .addSectionComponents(
                    new SectionBuilder()
                        .setThumbnailAccessory(new ThumbnailBuilder().setURL(WARNING_ICON_URL))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder()
                                .setContent("## ⚠️ Sentinel System | Configuração de Cargos Necessária\n\nO sistema está ativo no banco de dados, **mas você precisa configurar os cargos de Warn**.\n\n> O meu desenvolvedor implementou um sistema de cargos obrigatório para que vocês possam detectar visualmente e facilmente quais usuários estão com punições ativas no servidor.\n\n**Ação Necessária:**\nUtilize o comando `/warnconfig` para definir a hierarquia de cargos e validar o funcionamento completo do módulo.")
                        )
                )
                .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small));

            return interaction.editReply({
                components: [containerConfigError],
                flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2
            });
        }

        let hasAccess = false;
        const isOwner = member.id === config.ownerId;
        const hasNativePermission = member.permissions.has(PermissionFlagsBits.ManageMessages);
        
        // Verifica no banco de dados se o usuário específico tem permissão de teste/bypass
        const isPermittedUser = await PermittedUsers.exists({ userId: member.id });

        if (isOwner || hasNativePermission || isPermittedUser) {
            hasAccess = true;
        }

        if (!hasAccess) {
            const containerErroPerm = new ContainerBuilder()
                .setAccentColor(0xED4245)
                .addSectionComponents(
                    new SectionBuilder()
                        .setThumbnailAccessory(new ThumbnailBuilder().setURL(WARNING_ICON_URL))
                        .addTextDisplayComponents(new TextDisplayBuilder().setContent('## 🚫 Acesso Negado\nVocê não possui as credenciais de segurança necessárias para acessar o painel de avisos do Sentinel System.\n\n**Requisitos:**\n- Permissão de `Gerenciar Mensagens`.'))
                );

            return interaction.editReply({
                components: [containerErroPerm],
                flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2
            });
        }

        const warns = await Warn.find({ guildId: guild.id }).lean();

        if (!warns.length) {
            const containerSemAvisos = new ContainerBuilder()
                .setAccentColor(0x57F287)
                .addSectionComponents(
                    new SectionBuilder()
                        .setThumbnailAccessory(new ThumbnailBuilder().setURL(THUMBNAIL_URL))
                        .addTextDisplayComponents(new TextDisplayBuilder().setContent('## 🟡 Status do Sistema: Limpo\nNão foram encontrados registros de avisos ativos para nenhum usuário neste servidor.'))
                );

            return interaction.editReply({
                components: [containerSemAvisos],
                flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2
            });
        }

        const userWarns = {};
        for (const warn of warns) {
            if (!userWarns[warn.userId]) userWarns[warn.userId] = [];
            userWarns[warn.userId].push(warn);
        }

        const userIds = Object.keys(userWarns);
        
        let fetchedMembers;
        try {
            fetchedMembers = await guild.members.fetch({ user: userIds }).catch(() => new Map());
        } catch {
            fetchedMembers = new Map();
        }

        const options = [];
        const maxWarns = warnConfig.maxWarns || 3;

        for (const userId of userIds) {
            if (options.length >= 24) break;

            const memberFetched = fetchedMembers.get(userId);
            
            if (!memberFetched) continue;

            const warnCount = userWarns[userId].length;

            options.push({
                label: `${memberFetched.user.username} (${warnCount}/${maxWarns} avisos)`,
                description: `ID: ${userId}`,
                value: userId,
                emoji: '<:Member:1427164040362197104>'
            });
        }

        if (options.length === 0) {
            const containerVazioAposFiltro = new ContainerBuilder()
                .setAccentColor(0xFFA500)
                .addSectionComponents(
                    new SectionBuilder()
                        .setThumbnailAccessory(new ThumbnailBuilder().setURL(THUMBNAIL_URL))
                        .addTextDisplayComponents(new TextDisplayBuilder().setContent('## 🟡 Nenhum Usuário Ativo Encontrado\nExistem registros de avisos no banco de dados, mas os usuários associados não estão mais presentes no servidor (saíram ou foram banidos).'))
                );

            return interaction.editReply({
                components: [containerVazioAposFiltro],
                flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2
            });
        }

        options.push({
            label: ' Pesquisar usuário...',
            description: 'Digite o ID de um usuário específico para gerenciar.',
            value: 'pesquisar',
            emoji: '<:emoji_47:1427167789621444758>'
        });

        const selectMenu = new StringSelectMenuBuilder()
            .setCustomId('aviso_selecionar_usuario')
            .setPlaceholder('👤 Selecione um usuário para gerenciar ou pesquisar...')
            .addOptions(options);

        const row = new ActionRowBuilder().addComponents(selectMenu);

        const descricaoPainel = `## <:Icon_Moderation:1427138768338681856> Painel de Avisos - **Sentinel System**\n\n<:Icon_Mention:1427142137887195248> Olá, ${interaction.user}!\nBem-vindo ao **Painel de Avisos**. Aqui você pode gerenciar os avisos da comunidade de forma rápida, eficiente e integrada ao novo sistema de configurações.\n\n### Ferramentas Administrativas:\n\n- **<:Icon_Context_Menus:1427142449939222679> Ver Avisos:** Visualize o histórico detalhado e motivos.\n- **<:Icon_DeleteMessage:1427138931039928330> Remover Avisos:** Reduza a pena de usuários (o sistema reajustará os cargos automaticamente).\n- **<a:Sik:1427141359613120522> Gerenciamento:** Acesso rápido a Banimentos, Expulsões e Mutes.\n\n**<:Icon_Message_Pin:1427139244006047804> Nota:** Todas as ações são sincronizadas com a configuração definida em \`/warnconfig\`.`;

        const painelContainer = new ContainerBuilder()
            .setAccentColor(5793266)
            .addSectionComponents(
                new SectionBuilder()
                    .setThumbnailAccessory(new ThumbnailBuilder().setURL(THUMBNAIL_URL))
                    .addTextDisplayComponents(new TextDisplayBuilder().setContent(descricaoPainel))
            )
            .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small))
            .addActionRowComponents(row);

        await interaction.editReply({
            components: [painelContainer],
            flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2
        });
    }
};