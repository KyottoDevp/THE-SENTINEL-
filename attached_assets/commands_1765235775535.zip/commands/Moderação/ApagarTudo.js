const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');

const nukingChannels = new Set();

module.exports = {
  data: new SlashCommandBuilder()
    .setName('nuke')
    .setDescription('apaga e recria um canal com as mesmas permissões.')
    .addChannelOption(option =>
      option.setName('channel')
        .setDescription('The channel to be nuked.')
        .setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

  async execute(interaction) {
    const channel = interaction.options.getChannel('channel');

    // ---------- ERROR: Channel already being nuked ----------
    if (nukingChannels.has(channel.id)) {
      const embed = new EmbedBuilder()
        .setTitle("❌ Channel Already Nuking")
        .setDescription("This channel is already being nuked. Please wait until the process finishes.")
        .setColor(0xFF5555)
        .setThumbnail("https://iili.io/FWpkzps.png")
        .setFooter({ text: "Hornet Moderation System", iconURL: "https://iili.io/FWps6Yv.png" })
        .setTimestamp();
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    // ---------- ERROR: Missing permissions ----------
    if (!interaction.member.permissions.has(PermissionFlagsBits.ManageChannels)) {
      const embed = new EmbedBuilder()
        .setTitle("❌ Permission Denied")
        .setDescription("You do not have permission to manage channels.")
        .setColor(0xFF5555)
        .setThumbnail("https://iili.io/FWpkzps.png")
        .setFooter({ text: "Hornet Moderation System", iconURL: "https://iili.io/FWps6Yv.png" })
        .setTimestamp();
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    if (!interaction.guild.members.me.permissions.has(PermissionFlagsBits.ManageChannels)) {
      const embed = new EmbedBuilder()
        .setTitle("❌ Bot Missing Permission")
        .setDescription("I do not have permission to manage channels.")
        .setColor(0xFF5555)
        .setThumbnail("https://iili.io/FWpkzps.png")
        .setFooter({ text: "Hornet Moderation System", iconURL: "https://iili.io/FWps6Yv.png" })
        .setTimestamp();
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    nukingChannels.add(channel.id);
    const cleanup = () => nukingChannels.delete(channel.id);

    try {
      await interaction.deferReply({ ephemeral: true });

      const currentChannel = interaction.guild.channels.cache.get(channel.id);
      if (!currentChannel) {
        cleanup();
        const embed = new EmbedBuilder()
          .setTitle("❌ Channel Not Found")
          .setDescription("The channel no longer exists or has been deleted.")
          .setColor(0xFF5555)
          .setThumbnail("https://iili.io/FWpkzps.png")
          .setFooter({ text: "Hornet Moderation System", iconURL: "https://iili.io/FWps6Yv.png" })
          .setTimestamp();
        return interaction.editReply({ embeds: [embed], ephemeral: true });
      }

      const position = currentChannel.position;
      const name = currentChannel.name;
      const parent = currentChannel.parent;

      // Clone the channel
      let newChannel;
      try {
        newChannel = await currentChannel.clone({ name, reason: `Channel nuked by ${interaction.user.tag}` });
        if (parent) await newChannel.setParent(parent);
        await newChannel.setPosition(position);
      } catch (cloneErr) {
        console.error('[NUKE] Error cloning channel:', cloneErr);
        cleanup();
        const embed = new EmbedBuilder()
          .setTitle("❌ Clone Failed")
          .setDescription("Failed to clone the channel. Check my permissions and try again.")
          .setColor(0xFF5555)
          .setThumbnail("https://iili.io/FWpkzps.png")
          .setFooter({ text: "Hornet Moderation System", iconURL: "https://iili.io/FWps6Yv.png" })
          .setTimestamp();
        return interaction.editReply({ embeds: [embed], ephemeral: true });
      }

      // Delete the old channel
      try {
        await currentChannel.delete(`Nuke executed by ${interaction.user.tag}`);
      } catch (deleteErr) {
        console.error('[NUKE] Failed to delete original channel:', deleteErr);
        const embed = new EmbedBuilder()
          .setTitle("⚠️ Original Channel Not Deleted")
          .setDescription("The clone was created, but the original channel could not be deleted.")
          .setColor(0xFFA500)
          .setThumbnail("https://iili.io/FWpkzps.png")
          .setFooter({ text: "Hornet Moderation System", iconURL: "https://iili.io/FWps6Yv.png" })
          .setTimestamp();
        cleanup();
        return interaction.editReply({ embeds: [embed], ephemeral: true });
      }

      // Message in the new channel
      await newChannel.send({
        embeds: [
          new EmbedBuilder()
            .setTitle("💣 Channel Nuked")
            .setDescription(`**Channel:** ${newChannel}\n**Executed by:** ${interaction.user}\n**All previous messages were permanently deleted.**`)
            .setColor(0x55FF55)
            .setThumbnail("https://iili.io/FWpkzps.png")
            .setFooter({ text: "Hornet Moderation System", iconURL: "https://iili.io/FWps6Yv.png" })
            .setTimestamp()
        ]
      }).catch(console.error);

      // Confirmation to executor
      const confirmationEmbed = new EmbedBuilder()
        .setTitle("✅ Channel Nuked Successfully")
        .setDescription(`**Channel Recreated:** ${newChannel}`)
        .setColor(0x00AAFF)
        .setThumbnail("https://iili.io/FWpkzps.png")
        .setFooter({ text: "Hornet Moderation System", iconURL: "https://iili.io/FWps6Yv.png" })
        .setTimestamp();

      await interaction.editReply({ embeds: [confirmationEmbed] });

      cleanup();

    } catch (err) {
      console.error('[NUKE] Unexpected error:', err);
      cleanup();

      const embed = new EmbedBuilder()
        .setTitle("❌ Unexpected Error")
        .setDescription("An unexpected error occurred while trying to nuke the channel.")
        .setColor(0xFF5555)
        .setThumbnail("https://iili.io/FWpkzps.png")
        .setFooter({ text: "Hornet Moderation System", iconURL: "https://iili.io/FWps6Yv.png" })
        .setTimestamp();

      if (interaction.deferred || interaction.replied) {
        await interaction.editReply({ embeds: [embed], ephemeral: true });
      } else {
        await interaction.reply({ embeds: [embed], ephemeral: true });
      }
    }
  }
};
